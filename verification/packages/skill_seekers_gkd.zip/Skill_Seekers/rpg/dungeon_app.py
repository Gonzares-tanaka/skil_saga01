"""Small exploration screens around the existing battle UI."""
from collections import deque
from copy import deepcopy
import json

import pyxel

from .app import App
from .art import draw_quest_symbol
from .battle_presentation import battle_area, draw_status_icons
from .battle import Session
from .save import SaveManager, SaveError, NoSaveError
from .suspend import SuspendManager, job_result
from .final_battle import (FinalBattleCheckpoint, load_final_battle_data,
                          make_final_enemy)
from .content import ROOT
from .dungeon import Dungeon, load_dungeon_settings
from .exploration import Exploration
from .text import FONT_HEIGHT, fit, text, text_width, wrap_lines
from .map_resources import load_maps
from .growth import spark_probability
from .growth import growth_bonus
from .labels import EFFECTS, CATEGORIES
from .labels import CURRENCY_NAME
from .quests import (QUEST_TYPES, QUEST_NAMES, QUEST_SYMBOLS, QUEST_FLAVOR_MAX_CHARS,
                     QUEST_FLAVOR_LINE_HEIGHT, QUEST_FLAVOR_LINES_PER_PAGE)
from .models import effect_factor, battle_agility
from .items import ITEMS, RETURN_FEATHER
from .postgame_ui import PostgameMixin,POSTGAME_STATES
from .postgame import dragon_here
from .elevator import (unlocked_destinations, arrival_point, b15_elevator_point,
                       at_b15_elevator, B15_ELEVATOR_SPRITE)
from .opening import (TITLE_OPTIONS, TITLE_FADE_FRAMES,
                       NEW_GAME_BANKED_TRZ,
                      HUB_PREVIEW_FRAMES,
                      INTRO_MARGIN, INTRO_LINE_HEIGHT, load_intro_pages,
                      load_hub_intro_lines)
from .battle_transition import (BATTLE_TRANSITION_HOLD_FRAMES, BATTLE_TRANSITION_FRAMES,
                                BATTLE_TRANSITION_FLASH_FRAMES, draw_pieces)
from .final_presentation import AMRITA_BREAK_FRAME
from .hub import (HUB_IMAGE_BANK, HUB_PICTURE_SIZE, HUB_FACILITIES, HUB_ICONS, HUB_PICTURES,
                  HUB_DESCRIPTIONS, HUB_MENUS, HUB_FACILITY_LABELS, HUB_MENU_LABELS,
                  HUB_MENU_Y, HUB_MENU_STEP,
                  HUB_POSITIONS, HUB_SELECTION_WIDTHS, HUB_ICON_ELEVATOR,
                  HUB_CURRENCY_RIGHT, HUB_CURRENCY_Y, HUB_CURRENCY_WIDTH)
from .sound import (play_cue, start_battle_music, stop_battle_music, area_bgm, FIELD_SE,
                    TITLE_STATES, HUB_STATES, FIELD_STATES, BATTLE_STATES, BATTLE_BGM)
from .tiles import (DUNGEON_RESOURCE, MAP_IMAGE_BANK, BOSS_FLOORS,
                    TILE_CHEST_OPEN, TILE_BOSS, TILE_BOSS_CLEAR, TILE_SIZE,
                    TILE_FLOOR, FLOOR_TILES, TILE_RARE_CHEST, TILE_QUEST,
                    TILE_SWITCH, TILE_SWITCH_ON, TILE_DOOR, TILE_DOOR_OPEN,
                    TILE_GUARDIAN, TILE_WARNING)


MAP_X, MAP_Y = 2, 13
MAP_WIDTH = MAP_HEIGHT = 96
PLAYER_WIDTH = PLAYER_HEIGHT = 16
PLAYER_SPRITES = {"up": (64, 0), "down": (80, 0),
                  "right": (96, 0), "left": (112, 0)}
TRANSITION_INPUTS = (pyxel.KEY_UP, pyxel.KEY_DOWN, pyxel.KEY_LEFT, pyxel.KEY_RIGHT,
                     pyxel.KEY_Z, pyxel.KEY_X, pyxel.KEY_RETURN, pyxel.KEY_SPACE,
                     pyxel.KEY_ESCAPE, pyxel.GAMEPAD1_BUTTON_DPAD_UP,
                     pyxel.GAMEPAD1_BUTTON_DPAD_DOWN, pyxel.GAMEPAD1_BUTTON_DPAD_LEFT,
                     pyxel.GAMEPAD1_BUTTON_DPAD_RIGHT, pyxel.GAMEPAD1_BUTTON_A,
                     pyxel.GAMEPAD1_BUTTON_B)
FINAL_EVENT_STATES = ('amrita_offer', 'final_story', 'final_retry', 'ending')
TRAVEL_STATES = ('elevator', 'elevator_return', 'feather_return')
# Keep the original six indices, including suspend, stable for existing input.
EXPLORATION_MENU = ('状態', '習得技', '道具', 'return', 'ヘルプ', '中断', 'クエスト')


class DungeonApp(PostgameMixin,App):
    def __init__(self, session, run=True, headless=False, start_at_title=True, save_backend=None,
                 suspend_backend=None):
        if not DUNGEON_RESOURCE.is_file():
            raise ValueError("game.pyxresがありません。同梱リソースを戻してください。")
        super().__init__(session, run=False, headless=headless, battle_on_start=False)
        self.save_manager = SaveManager(save_backend)
        self.suspend_manager = SuspendManager(suspend_backend)
        self.suspend_available = False
        self.suspend_job = None
        self.suspend_choice = 1
        self.suspend_error = ''
        self.save_choice = 0
        self.save_message = ""
        self.title_save_message = "セーブデータがありません"
        self.initial_content = deepcopy((session.settings, session.skills,
                                         session.party, session.enemy_data))
        self.initial_rng_state = session.rng.getstate()
        self.initial_debug = session.debug
        self.intro_pages = load_intro_pages()
        self.hub_intro_lines = load_hub_intro_lines()
        self.hub_intro_shown = False
        self.title_cursor = self.intro_page = self.title_fade_remaining = 0
        self.hub_preview_remaining = 0
        self.opening_input_blocked = False
        self.dungeon = Dungeon(load_maps(), session.enemy_data, load_dungeon_settings(), session.rng,
                               session.treasure, session.inventory)
        self.rumors = json.loads((ROOT / "data/pub_messages.json").read_text(encoding="utf-8-sig"))
        self.last_rumor = None
        self.exploration = Exploration(session, self.dungeon)
        self.quest_cursor = self.feedback_cursor = 0
        self.quest_type_cursor = 0
        self.quest_flavor_page = 0
        self.quest_offer_cursor = 0
        self.quest_thanks_page = 0
        self.quest_completion_receipt = None
        self.relearn_cursor = self.treasure_cursor = 0
        self.return_lines = []
        self.return_back_state, self.return_back_overlay = "menu", None
        self.player_facing = "down"
        self.floor_cursor = self.effect_cursor = self.message_page = 0
        self.menu_cursor = self.item_cursor = self.camp_cursor = self.catalog_cursor = 0
        self.facility_cursor = self.facility_index = 0
        self.facility_back = "camp"
        self.item_kind_cursor = self.shop_cursor = self.pub_cursor = 0
        self.elevator_cursor = 0
        self.travel_choice = 1
        self.archive_cursor = 0
        self.archive_page = 0
        self.battle = None
        self.battle_is_boss = False
        self.battle_kind = 'normal'
        self.next_guardian_index = None
        self.battle_position = None
        self.battle_transition_image = pyxel.Image(pyxel.width, pyxel.height)
        self.battle_transition_frame = 0
        self.battle_transition_hold = 0
        self.battle_input_blocked = False
        self.final_battle_data = load_final_battle_data()
        self.final_checkpoint = None
        self.final_choice = self.final_story_page = self.ending_page = 0
        self.final_question_page = 0
        self.camp_offer_pending = False
        self.explore_message = "入口へ戻ると全回復"
        self.hunt_goal_lines = None
        self.init_postgame()
        self.enter_camp(play_music=not start_at_title)
        if start_at_title:
            self.state = "title"
        self.sync_scene_audio()
        self.refresh_suspend()
        if run:
            pyxel.run(self.update, self.draw)

    def start_new_game(self):
        """Reset every run-owned system before the opening story begins."""
        self.init_postgame()
        self.final_presentation = None
        self.session = Session(*deepcopy(self.initial_content))
        self.session.treasure.banked = NEW_GAME_BANKED_TRZ
        self.session.rng.setstate(self.initial_rng_state)
        self.session.debug = self.initial_debug
        self.dungeon = Dungeon(load_maps(), self.session.enemy_data,
                               load_dungeon_settings(), self.session.rng,
                               self.session.treasure, self.session.inventory)
        self.exploration = Exploration(self.session, self.dungeon)
        self.quest_thanks_page = 0
        self.quest_completion_receipt = None
        self.last_rumor = None
        self.return_lines = []
        self.return_back_state, self.return_back_overlay = "menu", None
        self.battle = None
        self.battle_is_boss = False
        self.battle_position = None
        self.battle_kind = 'normal'
        self.next_guardian_index = None
        self.final_checkpoint = None
        self.final_choice = self.final_story_page = self.ending_page = 0
        self.final_question_page = 0
        self.camp_offer_pending = False
        self.player_facing = "down"
        self.overlay = None
        self.notice = ""
        self.enter_camp(play_music=False)
        self.intro_page = 0
        self.hub_intro_shown = False
        self.hub_preview_remaining = 0
        self.title_fade_remaining = TITLE_FADE_FRAMES
        self.opening_input_blocked = True
        self.state = "title_fade"
        self.sync_scene_audio()

    def update_opening(self):
        if self.state == "title_fade":
            self.title_fade_remaining -= 1
            if self.title_fade_remaining <= 0:
                self.state = "intro"
            return
        if self.state == "hub_preview":
            self.hub_preview_remaining -= 1
            if self.hub_preview_remaining <= 0:
                self.state = "hub_intro"
            return
        if self.opening_input_blocked:
            if not any(pyxel.btn(button) for button in TRANSITION_INPUTS):
                self.opening_input_blocked = False
            return
        if self.state == "title":
            self.title_cursor = (self.title_cursor + self.direction()) % len(self.title_options())
            if self.confirm():
                if self.title_cursor == 0:
                    self.start_new_game()
                elif self.title_cursor == 1:
                    self.continue_game()
                else:
                    self.state, self.suspend_operation = 'suspend_busy', 'read'
                    self.suspend_job = self.suspend_manager.backend.start('read')
        elif self.state == "title_no_save":
            if self.confirm() or self.cancel():
                self.state = "title"
        elif self.state == "intro" and self.confirm():
            if self.intro_page + 1 < len(self.intro_pages):
                self.intro_page += 1
            else:
                if self.hub_intro_shown:
                    self.enter_camp()
                else:
                    self.hub_preview_remaining = HUB_PREVIEW_FRAMES
                    self.opening_input_blocked = True
                    self.state = "hub_preview"
                    self.sync_scene_audio()
        elif self.state == "hub_intro" and self.confirm():
            self.hub_intro_shown = True
            self.enter_camp()
            self.opening_input_blocked = True

    def draw_title_logo(self):
        """Draw the user-owned logo at native size, including its color-0 background."""
        width, height = 128, 32
        pyxel.blt((pyxel.width - width) // 2, 23, 1, 0, 192, width, height)

    def draw_title_menu(self):
        options = self.title_options()
        for index, label in enumerate(options):
            y = 65 + index * 14 if len(options) == 3 else 70 + index * 17
            display = ("> " if index == self.title_cursor else "  ") + label
            width = text_width(display)
            x = (pyxel.width - width) // 2
            if index == self.title_cursor:
                pyxel.rect(x - 5, y - 2, width + 10, 13, 1)
            text(x, y, display, 3 if index == self.title_cursor else 2)

    def draw_title(self):
        pyxel.cls(0)
        pyxel.line(17, 21, 142, 21, 1)
        self.draw_title_logo()
        pyxel.line(17, 57, 142, 57, 1)
        self.draw_title_menu()
        self.footer("D-PAD:選択 A:決定")

    def draw_title_no_save(self):
        pyxel.cls(0)
        self.draw_title_logo()
        pyxel.rect(14, 68, 132, 22, 1)
        message = self.title_save_message
        text((pyxel.width - text_width(message)) // 2, 75, message, 3)
        self.footer("A/B:タイトルへ")

    def draw_opening_page(self, lines):
        """Center editable story lines, including their intentional blank lines."""
        pyxel.cls(3)
        display_lines = wrap_lines(lines, (pyxel.width - 2 * INTRO_MARGIN) // 4)
        count = len(display_lines)
        line_height = min(INTRO_LINE_HEIGHT, max(FONT_HEIGHT,
                          (pyxel.height - 2 * INTRO_MARGIN - FONT_HEIGHT) // max(1, count - 1)))
        block_height = FONT_HEIGHT + (count - 1) * line_height
        y = (pyxel.height - block_height) // 2
        for line in display_lines:
            if line:
                text((pyxel.width - text_width(line)) // 2, y, line, 0)
            y += line_height

    def draw_intro(self):
        self.draw_opening_page(self.intro_pages[self.intro_page])

    def draw_hub_intro(self):
        self.draw_opening_page(self.hub_intro_lines)

    def can_save_game(self):
        f = self.dungeon.finale
        return (self.state in ('facility', 'save_confirm') and self.facility_index == 0
                and self.overlay is None and self.final_checkpoint is None
                and f.guardian_index is None
                and not (f.final_event_started and not f.lord_of_elysion_defeated)
                and not self.session.pending_replacements
                and not (self.session.battle and not self.session.settled)
                and not self.exploration.completion_ready)

    def title_options(self):
        return TITLE_OPTIONS + (('中断から',) if getattr(self, 'suspend_available', False) else ())

    def refresh_suspend(self):
        self.suspend_operation = 'exists'
        self.suspend_job = self.suspend_manager.backend.start('exists')

    def can_suspend_game(self):
        s, f = self.session, self.dungeon.finale
        return (self.state in ('explore', 'menu', 'suspend_confirm') and self.overlay is None
                and not s.pending_replacements and s.pending_relearn is None
                and not (s.battle and not s.settled)
                and f.guardian_index is None and not f.final_event_started
                and self.final_checkpoint is None and not self.exploration.completion_ready
                and self.exploration.pending_quest is None)

    def update_suspend_io(self):
        job = getattr(self, 'suspend_job', None)
        if job is None or not job.done:
            return self.state == 'suspend_busy'
        self.suspend_job = None
        operation = self.suspend_operation
        try:
            value = job_result(job)
            if operation == 'exists':
                self.suspend_available = bool(value)
                self.title_cursor %= len(self.title_options())
                return False
            if operation == 'write':
                self.suspend_available = True
                self.state, self.overlay, self.title_cursor = 'title', None, 2
                self.opening_input_blocked = True
                self.audio.pending_se = None
                self.sync_scene_audio()
            elif operation == 'read':
                self.suspend_prepared = self.suspend_manager.prepare(self, value)
                self.suspend_prepared = self.merge_saved_completion(self.suspend_prepared)
                self.suspend_operation = 'consume'
                self.suspend_job = self.suspend_manager.backend.start('consume', value)
            else:
                self.activate_suspended_game(self.suspend_prepared)
                self.suspend_prepared = None
                self.suspend_available = False
        except Exception as error:
            print('SUSPEND failed:', repr(error))
            if operation == 'exists':
                self.suspend_available = False
                return False
            self.suspend_prepared = None
            if operation == 'write':
                self.state, self.suspend_error = 'suspend_confirm', '保存できませんでした'
                self.suspend_choice = 1
            else:
                self.state = 'title_no_save'
                self.title_save_message = '中断を再開できません'
                self.title_cursor = 0
                self.refresh_suspend()
            self.opening_input_blocked = True
        return True

    def activate_suspended_game(self, prepared):
        self.session, self.dungeon, self.exploration, self.hub_intro_shown, ui = prepared
        self.player_facing, self.last_rumor = ui['player_facing'], ui['last_rumor']
        self.explore_message = ui['explore_message']
        self.battle = self.final_checkpoint = self.final_presentation = self.battle_presentation = None
        self.battle_kind, self.battle_is_boss = 'normal', False
        self.battle_position = self.next_guardian_index = None
        self.fanfare_started_at = self.fanfare_start_frame = None
        self.fanfare_timed_out = self.battle_input_blocked = False
        self.actions, self.pending, self.log = [], deque(), []
        self.selected_skill = self.selected_item = None
        self.audio.pending_se = None
        self.hunt_goal_lines = None
        self.camp_offer_pending = False
        self.quit_select_started_at = None
        self.notice, self.notice_timer, self.shake_timer = '', 0, 0
        self.menu_cursor = self.info_character = self.info_tab = self.scroll = 0
        self.debug_return_state, self.debug_return_overlay = None, 'debug_skills'
        self.state, self.overlay = 'explore', None
        self.opening_input_blocked = True
        self.sync_scene_audio()

    def update_suspend_confirm(self):
        self.suspend_choice = (self.suspend_choice + self.direction()) % 2
        if self.cancel() or self.confirm() and self.suspend_choice:
            self.state = 'menu'
        elif self.confirm():
            try:
                self.suspend_job = self.suspend_manager.save(self)
                self.suspend_operation, self.state = 'write', 'suspend_busy'
            except Exception as error:
                print('SUSPEND save failed:', repr(error))
                self.suspend_error = '今は中断できません'
                self.suspend_choice = 1

    def draw_suspend(self):
        self.title('中断 / SUSPEND')
        if self.state == 'suspend_busy':
            text(8, 48, '中断データを処理中です', 3, 36)
            text(8, 66, 'そのままお待ちください', 2, 36)
            return
        text(8, 24, '現在の冒険を保存して', 3, 36)
        text(8, 36, '中断しますか？', 3, 36)
        for i, label in enumerate(('はい', 'いいえ')):
            text(24, 57 + i * 14, ('> ' if i == self.suspend_choice else '  ') + label, 3)
        text(8, 92, self.suspend_error or '再開した中断データは消えます', 2, 36)
        self.footer('A:決定 B:戻る')

    def continue_game(self):
        try:
            self.save_manager.load(self)
        except Exception as error:
            print('LOAD failed:', repr(error))
            self.title_save_message = ('セーブデータがありません' if isinstance(error, NoSaveError)
                                       else 'セーブデータを読み込めません')
            self.state = 'title_no_save'
            return
        stop_battle_music()
        # Loaded gameplay objects are detached/new; discard only obsolete UI waits.
        self.audio.pending_se = None
        self.hunt_goal_lines = None
        self.battle = self.final_checkpoint = self.final_presentation = None
        self.battle_kind, self.battle_is_boss = 'normal', False
        self.battle_position = self.next_guardian_index = None
        self.fanfare_started_at = self.fanfare_start_frame = None
        self.fanfare_timed_out = False
        self.battle_input_blocked = False
        self.actions, self.pending, self.log = [], deque(), []
        self.return_lines = []
        self.return_back_state, self.return_back_overlay = 'menu', None
        self.quest_completion_receipt = None
        self.quest_thanks_page = self.quest_flavor_page = self.quest_offer_cursor = 0
        self.info_character = self.info_tab = self.scroll = 0
        self.camp_cursor = self.facility_index = self.facility_cursor = self.menu_cursor = 0
        self.facility_back, self.player_facing = 'camp', 'down'
        self.camp_offer_pending = False
        self.notice, self.notice_timer, self.shake_timer = '', 0, 0
        self.last_rumor = None
        self.debug_return_state, self.debug_return_overlay = None, 'debug_skills'
        self.state, self.overlay = 'camp', None
        self.camp_message = 'セーブを読み込みました'
        self.hub_preview_remaining = self.title_fade_remaining = self.intro_page = 0
        self.opening_input_blocked = True
        self.sync_scene_audio()

    def enter_camp(self, defeated=False, returned=False, *, play_music=True):
        self.hunt_goal_lines = None
        self.audio.pending_se = None
        self.dungeon.finale.abort_guardians()
        self.next_guardian_index = None
        quest_failure = []
        if returned:
            self.return_secured = self.session.treasure.secure()
            self.exploration.return_to_camp(True, defer_completion=True)
        elif defeated:
            quest_failure = self.exploration.return_to_camp(False)
        for actor in self.session.party:
            actor.recover()
        self.state, self.overlay = "camp", None
        self.camp_cursor = 0
        self.facility_back = "camp"
        self.notice_timer = 0
        self.camp_message = "全滅・回復 / 調査はやり直し" if defeated else "全員のHPを回復しました"
        # All ordinary external arrivals use returned/defeated. Facility exits
        # only change state to camp and cannot re-open this confirmation.
        self.camp_offer_pending = bool((returned or defeated) and self.dungeon.finale.can_offer_amrita)
        self.final_choice = 0
        self.final_question_page = 0
        if returned:
            self.quest_thanks_page = 0
            self.quest_completion_receipt = None
            self.state = "quest_thanks" if self.exploration.completion_ready else "return_result"
        elif quest_failure:
            self.show_field_event(quest_failure, return_state='amrita_offer' if self.camp_offer_pending else 'camp')
            self.camp_offer_pending = False
        elif self.camp_offer_pending:
            self.show_amrita_offer()
        if play_music:
            self.audio.play_bgm('bgm_hub')

    def enter_dungeon(self):
        if self.dungeon.cleared:
            # A new trip always starts at B1, even after the clear banner.
            self.dungeon.enter(allow_cleared=True)
            self.exploration.springs.clear()
            self.player_facing = "down"
            self.state, self.notice_timer = "explore", 0
            self.audio.play_bgm(area_bgm(self.dungeon.floor))
            return
        self.dungeon.enter()
        self.exploration.springs.clear()
        self.player_facing = "down"
        self.state = "explore"
        self.explore_message = "入口から出発した"
        if self.exploration.hint():
            self.show_field_event([self.exploration.hint()])
        self.audio.play_bgm(area_bgm(self.dungeon.floor))

    def travel_elevator(self, floor):
        """Resolve gates/landing first, then start the same new expedition."""
        if self.state != 'elevator' or self.overlay is not None:
            raise ValueError('エレベーターは拠点から利用してください')
        point = arrival_point(self.dungeon, floor)
        self.dungeon.enter(allow_cleared=True, encounter_floor=floor)
        self.dungeon.floor = floor
        self.dungeon.x, self.dungeon.y = point
        self.exploration.springs.clear()
        self.player_facing = 'down'
        self.state, self.overlay, self.notice_timer = 'explore', None, 0
        self.explore_message = f'エレベーターでB{floor + 1}Fに到着'
        self.opening_input_blocked = True
        # Arrival draws one interval for this AREA, but is not a walking step.
        if self.exploration.hint():
            self.show_field_event([self.exploration.hint()])
        self.audio.play_se(FIELD_SE['stairs'])
        self.audio.play_bgm(area_bgm(floor))

    def safe_return(self, lines):
        """One settlement path for walking, RETURN, feather and B15 lift."""
        self.return_lines = list(lines)
        self.enter_camp(returned=True)

    def can_use_return_feather(self):
        s, f = self.session, self.dungeon.finale
        return (self.state in ('items', 'feather_return') and self.overlay is None
                and not (s.battle and not s.settled)
                and not s.pending_replacements and s.pending_relearn is None
                and not s.field_pending and not s.debug_pending
                and f.guardian_index is None and not f.final_event_started
                and self.final_checkpoint is None and not self.exploration.pending_quest
                and not self.exploration.completion_ready)

    def use_return_feather(self):
        if not self.can_use_return_feather():
            raise ValueError('今は帰還の羽根を使えません')
        if self.session.inventory.counts[RETURN_FEATHER] <= 0:
            raise ValueError('帰還の羽根がありません')
        self.safe_return(['帰還の羽根で城下町へ戻った。'])
        # Charge only after the shared safe return has actually succeeded.
        self.session.inventory.counts[RETURN_FEATHER] -= 1

    def update_travel(self):
        if self.state == 'elevator':
            options = unlocked_destinations(self.dungeon) + [(None, 'もどる')]
            self.elevator_cursor = (self.elevator_cursor + self.direction()) % len(options)
            if self.cancel():
                self.state = 'camp'
            elif self.confirm():
                floor = options[self.elevator_cursor][0]
                if floor is None:
                    self.state = 'camp'
                else:
                    try:
                        self.travel_elevator(floor)
                    except ValueError as error:
                        self.tell(str(error))
            return
        feather = self.state == 'feather_return'
        self.travel_choice = (self.travel_choice + self.direction()) % 2
        if self.cancel() or self.confirm() and self.travel_choice:
            self.state = 'items' if feather else 'explore'
            self.opening_input_blocked = True
        elif self.confirm():
            try:
                if feather:
                    self.use_return_feather()
                elif (at_b15_elevator(self.dungeon) and
                      not (self.session.battle and not self.session.settled) and
                      not self.session.pending_replacements and self.session.pending_relearn is None and
                      self.dungeon.finale.guardian_index is None and
                      not self.dungeon.finale.final_event_started):
                    self.safe_return(['B15のエレベーターで城下町へ戻った。'])
                else:
                    raise ValueError('今はエレベーターで帰還できません')
                self.opening_input_blocked = True
            except (ValueError, OSError) as error:
                self.tell(str(error))

    def draw_travel(self):
        pyxel.cls(0)
        if self.state == 'elevator':
            self.title('エレベーター')
            options = unlocked_destinations(self.dungeon)
            if not options:
                text(7, 24, 'まだ行き先がありません', 2, 36)
            for i, (_, label) in enumerate(options + [(None, 'もどる')]):
                text(12, 48 + i*14, ('>' if i == self.elevator_cursor else ' ') + label,
                     3 if i == self.elevator_cursor else 2, 34)
            self.footer('上下:選択 A:移動 B:拠点')
        else:
            feather = self.state == 'feather_return'
            self.title('帰還の羽根' if feather else 'エレベーター / 帰還')
            text(7, 25, '城下町へ帰還しますか？', 3, 36)
            text(7, 39, f'未確定{CURRENCY_NAME}を確保します', 2, 36)
            if feather:
                text(7, 51, '帰還の羽根を1個使います', 2, 36)
            for i, label in enumerate(('はい', 'いいえ')):
                text(18, 72+i*14, ('>' if i == self.travel_choice else ' ') + label, 3, 30)
            self.footer('上下:選択 A:決定 B:取消')

    def begin_encounter(self, boss=False, animate=False, guardian_index=None, quest_hunt=False):
        self.final_presentation = None
        self.hunt_goal_lines = None
        boss = boss or guardian_index is not None
        animate = animate and not boss
        if animate:
            # Draw the current position, including the step that triggered battle.
            pyxel.cls(0)
            self.draw_explore()
            self.battle_transition_image.blt(0, 0, pyxel.screen, 0, 0,
                                             pyxel.width, pyxel.height)
        self.fanfare_started_at = None
        self.fanfare_start_frame = None
        self.battle_position = self.dungeon.floor, self.dungeon.x, self.dungeon.y
        self.battle_is_boss = boss
        self.battle_background_area = battle_area(self.dungeon.floor)
        self.battle_kind = ('quest_hunt' if quest_hunt else 'guardian' if guardian_index is not None else
                            'demon' if boss and self.dungeon.floor == 14 else
                            'boss' if boss else 'normal')
        enemies = self.exploration.make_hunt_enemy() if quest_hunt else self.dungeon.make_enemies(boss, guardian_index)
        self.battle = self.session.next_battle(enemies, recover=False,
                                               spark_multiplier=self.dungeon.spark_multiplier, boss=boss,
                                               persistent_poison=True)
        self.notice_timer = 0
        self.log = [self.battle.enemies[0].name + "との決戦!" if boss else "敵と遭遇した!"]
        self.pending = deque()
        self.begin_input()
        self.shake_timer = 0
        self.battle_input_blocked = animate
        self.debug_return_state = None
        self.debug_return_overlay = None
        if boss:
            start_battle_music(self.battle_kind)
        elif animate:
            self.state = "battle_transition"
            self.battle_transition_frame = 0
            self.battle_transition_hold = BATTLE_TRANSITION_HOLD_FRAMES
            play_cue("battle_transition")
        else:
            start_battle_music(self.battle_kind)

    def finish_results(self):
        if self.session.pending_replacements or self.waiting_for_fanfare():
            return
        stop_battle_music()
        if self.battle_kind == 'elysion':
            if self.battle.outcome == 'VICTORY':
                self.dungeon.finale.final_victory()
                self.complete_main_game()
            else:
                self.state, self.final_choice = 'final_retry', 0
                self.final_question_page = 0
            self.overlay, self.notice_timer = None, 0
            return
        if self.battle_kind == 'dragon' and self.battle.outcome == 'VICTORY':
            self.complete_dragon()
            return
        if self.battle.outcome != 'DEFEAT':
            # Shared by normal/quest/boss exits; never wait for an audio result.
            self.dungeon.reset_encounter()
        self.trace("RETURN MAP" if self.battle.outcome != "DEFEAT" else "RETURN CAMP")
        if self.battle.outcome == "DEFEAT":
            self.enter_camp(defeated=True)
        elif self.battle_kind == 'guardian':
            self.dungeon.floor, self.dungeon.x, self.dungeon.y = self.battle_position
            f = self.dungeon.finale
            if self.battle.outcome != 'VICTORY':
                f.abort_guardians()
                self.next_guardian_index = None
                self.show_field_event(['守護者との決着はつかなかった。', '連戦は最初からやり直しになる。'])
                return
            finished = f.guardian_victory()
            self.next_guardian_index = f.guardian_index
            self.message_lines = wrap_lines(f.data['guardian_after'] if finished else
                                             f.data['guardian_between'][f.guardian_index - 1], 36)
            self.state = 'guardian_after' if finished else 'guardian_between'
            self.message_page, self.notice_timer = 0, 0
        elif self.battle_is_boss and self.battle.outcome == "VICTORY":
            self.dungeon.floor, self.dungeon.x, self.dungeon.y = self.battle_position
            self.message_lines = wrap_lines(self.dungeon.defeat_boss(), 36)
            self.state, self.message_page = "boss_after", 0
            self.notice_timer = 0
        else:
            self.state = "explore"
            self.dungeon.floor, self.dungeon.x, self.dungeon.y = self.battle_position
            self.explore_message = "HPは持ち越し。進むか帰るか"
            self.notice_timer = 0
            if self.battle_kind == 'quest_hunt' and self.battle.outcome == 'VICTORY':
                self.observe_hunt_goal()
                self.show_field_event(self.hunt_goal_lines or [])
                if self.hunt_goal_lines:
                    self.audio.play_se('se_quest_complete')
                self.hunt_goal_lines = None
        self.sync_scene_audio()

    def next_result_label(self):
        if self.battle_kind == 'elysion':
            return '旅の結末へ' if self.battle.outcome == 'VICTORY' else '再挑戦の確認へ'
        if self.battle.outcome == "DEFEAT":
            return "拠点へ"
        if self.battle_kind == 'guardian' and self.battle.outcome == 'VICTORY':
            return '守護者との連戦へ'
        if self.battle_is_boss and self.battle.outcome == "VICTORY":
            return "撃破後の会話へ"
        return "探索へ"

    def handle_event(self, event, message):
        if event == 'lore':
            self.show_field_event(self.dungeon.finale.read(message))
            return
        if event == 'guardian':
            self.message_lines = wrap_lines(self.dungeon.finale.data['guardian_warning'], 36)
            self.message_page, self.notice_timer = 0, 0
            self.state, self.overlay = 'guardian_warning', None
            return
        if event == "chest":
            before_hp = [c.hp for c in self.session.party]
            lines = [message] + self.exploration.chest_effect(self.dungeon.last_reward)
            self.audio.play_se(FIELD_SE[event])
            if self.dungeon.last_reward['kind'] == 'TRAP' and before_hp != [c.hp for c in self.session.party]:
                self.audio.play_se('se_trap_damage', delay_frames=12)
            self.show_field_event(lines)
            return
        if event == "poison":
            before_hp = [c.hp for c in self.session.party]
            self.show_field_event([message] + self.exploration.damage(self.dungeon.exploration_settings["poison_damage"]))
            if before_hp != [c.hp for c in self.session.party]:
                self.audio.play_se(FIELD_SE[event])
            return
        if event in ("pit", "switch"):
            if event == 'pit': self.audio.play_se(FIELD_SE[event])
            self.show_field_event([message])
            return
        if event == "spring":
            key = self.dungeon.floor, self.dungeon.x, self.dungeon.y
            if key in self.exploration.springs:
                self.show_field_event(["泉は静かだ。次の探索でまた使える"])
            else:
                self.exploration.springs.add(key)
                self.show_field_event([message] + self.exploration.heal(None))
                self.audio.play_se(FIELD_SE[event])
            return
        if event == 'stairs':
            self.audio.play_se(FIELD_SE[event])
            self.audio.play_bgm(area_bgm(self.dungeon.floor))
        if event == "stairs" and self.exploration.hint():
            self.show_field_event([message, self.exploration.hint()])
            return
        if message:
            self.explore_message = message
            self.tell(message)
        if event == "boss":
            self.message_lines = wrap_lines(self.dungeon.boss_data["message"], 36)
            self.state, self.message_page, self.notice_timer = "boss_message", 0, 0
        elif event == "battle":
            self.begin_encounter(animate=True)
        elif event == "base":
            self.safe_return([])

    def sync_scene_audio(self):
        state = self.state
        if state == 'elevator': state = 'camp'
        if state in ('elevator_return', 'feather_return'): state = 'explore'
        if state == 'suspend_confirm': state = 'menu'
        if state == 'field_event': state = self.field_after
        if state == 'field_heal': state = self.field_return
        if state == 'field_return': state = self.return_back_state
        if state == 'credits':
            self.audio.play_bgm('bgm_credits')
        elif state in POSTGAME_STATES or state == 'ending':
            self.audio.stop_bgm()
        elif state in TITLE_STATES or state in ('title_fade', 'intro'):
            self.audio.play_bgm('bgm_title')
        elif state == 'final_story':
            self.audio.play_bgm('bgm_omen')
        elif state in HUB_STATES:
            self.audio.play_bgm('bgm_hub')
        elif state in FIELD_STATES:
            self.audio.play_bgm(area_bgm(self.dungeon.floor))
        elif state == 'guardian_between':
            self.audio.play_bgm('bgm_boss')
        elif state in BATTLE_STATES and self.battle and not self.battle.outcome:
            if self.battle_kind == 'elysion':
                before_break = (self.battle.elysion_barrier_active or state == 'amrita_effect'
                                and self.final_visual().frame < AMRITA_BREAK_FRAME)
                self.audio.play_bgm('bgm_boss' if before_break else 'bgm_final')
            else:
                self.audio.play_bgm(BATTLE_BGM.get(self.battle_kind, 'bgm_battle'))

    def observe_hunt_goal(self):
        q = self.exploration.active_quest
        if (self.battle_kind == 'quest_hunt' and self.battle and
                self.battle.outcome == 'VICTORY' and not self.session.settled and q and not q['completed']):
            # A settled victory is historical; it must never credit a newly
            # accepted contract. Observe the current kill before settlement.
            # Existing provisional completion, recorded immediately at the kill.
            # Only its sound waits until after the fixed victory presentation.
            self.hunt_goal_lines = self.exploration.hunt_victory()

    def apply_visual_action(self):
        super().apply_visual_action()
        self.observe_hunt_goal()

    def update(self):
        self.keyboard.update()
        if self.handle_quit_input():
            return
        if self.update_suspend_io():
            return
        self.audio.update()
        self.observe_hunt_goal()
        self.sync_scene_audio()
        if self.update_postgame():
            return
        if self.update_rescue_notice():
            return
        if self.state == 'resolve' and self.battle_visual().active:
            self.update_battle_visual()
            return
        if self.state == 'amrita_effect':
            super().update()
            return
        if self.state in ("title", "title_no_save", "title_fade", "intro",
                          "hub_preview", "hub_intro"):
            self.update_opening()
            return
        if self.state in FINAL_EVENT_STATES:
            self.update_final_event()
            return
        if self.opening_input_blocked:
            if not any(pyxel.btn(button) for button in TRANSITION_INPUTS):
                self.opening_input_blocked = False
            return
        if self.state == 'suspend_confirm':
            self.update_suspend_confirm()
            return
        if self.state in TRAVEL_STATES:
            self.notice_timer = max(0, self.notice_timer - 1)
            self.update_travel()
            return
        if self.overlay == 'field_quest':
            if self.cancel():
                self.overlay = None
            return
        if self.state == "battle_transition":
            if self.battle_transition_hold:
                self.battle_transition_hold -= 1
                return
            self.battle_transition_frame += 1
            if self.battle_transition_frame >= BATTLE_TRANSITION_FRAMES:
                self.state = "command"
                start_battle_music(self.battle_kind)
            return
        if self.battle_input_blocked:
            # Require a released frame, then a fresh press for the first command.
            if not any(pyxel.btn(button) for button in TRANSITION_INPUTS):
                self.battle_input_blocked = False
            return
        if self.state in ('guardian_warning', 'guardian_between', 'guardian_after'):
            self.update_guardians()
            return
        if self.session.debug and self.state == "explore" and not self.overlay and self.pressed(pyxel.KEY_T):
            self.begin_encounter(animate=True)
            return
        if self.session.debug and self.pressed(pyxel.KEY_F1) and self.state in ("camp", "explore"):
            self.overlay = None if self.overlay == "feedback_debug" else "feedback_debug"
            self.notice_timer = 0
            return
        if self.overlay in ("catalog", "dungeon_debug", "effects", "treasure_debug"):
            self.notice_timer = max(0, self.notice_timer - 1)
        if (self.overlay == "info" and self.info_tab == 1 and self.state in ("explore", "menu")
                and self.confirm()):
            actor = self.session.party[self.info_character]
            if actor.skills and self.session.skills[actor.skills[self.scroll]].effect == "return":
                self.open_return_skill(self.info_character, from_skills=True)
                return
            if (actor.skills and self.session.skills[actor.skills[self.scroll]].field_usable
                    and self.session.skills[actor.skills[self.scroll]].effect in ('heal', 'cure')):
                self.field_actor = self.info_character
                self.field_skill = actor.skills[self.scroll]
                self.field_return = self.state
                self.state, self.overlay, self.item_cursor = "field_heal", None, 0
                self.notice_timer = 0
                if self.session.skills[self.field_skill].target in ('self', 'all_allies'):
                    self.use_field_skill(self.field_actor)
                    self.state, self.overlay = self.field_return, 'info'
                    self.scroll = min(self.scroll, self.info_scroll_limit())
                return
        # Let the existing UI own all combat/inspection key handling.
        if self.pressed(pyxel.KEY_Q, pyxel.KEY_F9, pyxel.KEY_F12, pyxel.KEY_D, pyxel.KEY_TAB, pyxel.KEY_H):
            super().update()
            if not self.session.debug and self.overlay in ("catalog", "dungeon_debug", "effects", "treasure_debug", "feedback_debug"):
                self.overlay = None
            return
        if self.overlay == "feedback_debug":
            self.notice_timer = max(0, self.notice_timer - 1)
            self.update_feedback_debug()
            return
        if self.session.debug and self.pressed(pyxel.KEY_F2) and self.state in ("camp", "explore"):
            self.overlay = None if self.overlay == "treasure_debug" else "treasure_debug"
            self.notice_timer = 0
            return
        if self.overlay == "treasure_debug":
            self.update_treasure_debug()
            return
        if self.session.debug and self.pressed(pyxel.KEY_F4) and self.state in ("camp", "explore", "clear"):
            self.overlay = None if self.overlay == "dungeon_debug" else "dungeon_debug"
            self.floor_cursor = self.dungeon.floor
            self.notice_timer = 0
            return
        if self.session.debug and self.pressed(pyxel.KEY_F3) and self.battle and self.state in ("command", "skill", "target", "resolve", "result"):
            self.overlay = None if self.overlay == "effects" else "effects"
            self.notice_timer = 0
            return
        if self.session.debug and self.battle and self.state == "command":
            if self.pressed(pyxel.KEY_F6):
                self.battle.run_override = True
                self.tell("DEBUG: 次のRUNを成功に固定")
                return
            if self.pressed(pyxel.KEY_F8):
                self.battle.run_override = False
                self.tell("DEBUG: 次のRUNを失敗に固定")
                return
        if self.overlay == "dungeon_debug":
            self.update_dungeon_debug()
            return
        if self.overlay == "effects":
            self.effect_cursor = (self.effect_cursor + self.direction()) % (len(self.battle.enemies) + 4)
            if self.pressed(pyxel.KEY_X, pyxel.KEY_ESCAPE):
                self.overlay = None
            return
        if self.session.debug and self.pressed(pyxel.KEY_F10) and self.state != "replace":
            self.overlay = None if self.overlay == "catalog" else "catalog"
            self.notice_timer = 0
            return
        if self.overlay == "catalog":
            if self.pressed(pyxel.KEY_X, pyxel.KEY_ESCAPE):
                self.overlay = None
            else:
                self.catalog_cursor = (self.catalog_cursor + self.direction()) % len(self.session.skills)
                self.info_character = (self.info_character + self.direction(horizontal=True)) % 4
                skill = list(self.session.skills.values())[self.catalog_cursor]
                try:
                    if self.pressed(pyxel.KEY_C):
                        lines = self.session.debug_acquire(skill.id, self.info_character)
                        self.tell(lines[-1])
                    elif self.pressed(pyxel.KEY_V):
                        lines = self.session.debug_set_one(skill.id, self.info_character)
                        self.tell(lines[-1])
                    elif self.pressed(pyxel.KEY_B):
                        if not skill.can_relearn:
                            raise ValueError("再習得対象の技だけを発見できます。")
                        self.session.discovered_skills.add(skill.id)
                        self.tell(skill.name + " DISCOVERED")
                    elif self.pressed(pyxel.KEY_M):
                        self.session.mastered_skills.add(skill.id)
                        self.session.discovered_skills.add(skill.id)
                        self.tell(skill.name + " MASTERED! " + skill.mastery_label)
                    elif self.pressed(pyxel.KEY_R):
                        if self.state not in ("camp", "explore"):
                            raise ValueError("強制再取得は拠点か探索中だけです")
                        if skill.id not in self.session.mastered_skills:
                            raise ValueError("MでMASTEREDにしてください")
                        actor = self.session.party[self.info_character]
                        if skill.id in actor.skills:
                            actor.forget(skill.id)
                        self.tell(self.session.debug_acquire(skill.id, self.info_character)[-1])
                except ValueError as error:
                    self.tell(str(error))
                if self.session.pending_replacements:
                    self.debug_return_state = self.state
                    self.debug_return_overlay = "catalog"
                    self.state, self.overlay = "replace", None
                    self.replacement_cursor, self.replacement_confirm = 0, False
                    self.notice_timer = 0
            return
        if self.overlay:
            super().update()
            return
        if self.state in ("field_event", "quest_board", "quest_type", "quest_preview"):
            self.notice_timer = max(0, self.notice_timer - 1)
            self.update_field_ui()
            return
        if self.state in ("relearn_character", "relearn_list", "relearn_confirm", "field_return", "return_result",
                          "quest_thanks", "quest_reward", "quest_record", "save_confirm", "save_result"):
            self.notice_timer = max(0, self.notice_timer - 1)
            self.update_camp_resources()
            return
        if self.state not in ("camp", "facility", "archive", "explore", "menu", "items", "item_target", "shop", "pub", "field_heal", "clear", "boss_message", "boss_after"):
            super().update()
            return
        self.notice_timer = max(0, self.notice_timer - 1)
        if self.state in ("camp", "explore") and self.session.debug:
            if self.pressed(pyxel.KEY_F11):
                self.return_lines = ["DEBUG帰還"]
                self.enter_camp(returned=True)
                return
            if self.pressed(pyxel.KEY_F7):
                for actor in self.session.party:
                    actor.recover()
                self.tell("DEBUG: 全員全回復")
                return
            if self.pressed(pyxel.KEY_F5, pyxel.KEY_F6, pyxel.KEY_F8):
                floor = self.dungeon.floor + (-1 if self.pressed(pyxel.KEY_F5) else 1)
                if self.pressed(pyxel.KEY_F8):
                    floor = 4 if self.state == "camp" else next((f for f in BOSS_FLOORS if f > self.dungeon.floor), 4)
                self.state = "explore"
                self.dungeon.debug_floor(floor)
                if self.pressed(pyxel.KEY_F8):
                    self.dungeon.x, self.dungeon.y = self.dungeon.find(floor, TILE_BOSS)
                    if floor == 14:
                        self.dungeon.finale.guardians_defeated = True
                self.tell(f"DEBUG: {self.dungeon.floor + 1}Fへ移動")
                return
        confirm, cancel = self.confirm(), self.cancel()
        if self.state in ("boss_message", "boss_after"):
            if cancel and self.state == "boss_message":
                self.state = "explore"
            elif confirm:
                if (self.message_page + 1) * 8 < len(self.message_lines):
                    self.message_page += 1
                elif self.state == "boss_message":
                    self.begin_encounter(boss=True)
                else:
                    self.state = "explore"
                    self.explore_message = ('アムリタを持ち帰ろう' if self.dungeon.finale.has_amrita else
                                            '先の階層への道が開いた')
        elif self.state == "camp":
            horizontal = self.direction(horizontal=True)
            if horizontal and self.camp_cursor in (4, 5):
                self.camp_cursor = 5 if self.camp_cursor == 4 else 4
            else:
                self.camp_cursor = (self.camp_cursor + self.direction()) % len(HUB_FACILITIES)
            if confirm:
                if self.camp_cursor == 4:
                    self.enter_dungeon()
                elif self.camp_cursor == 5:
                    self.state, self.elevator_cursor = 'elevator', 0
                else:
                    self.facility_index = self.camp_cursor
                    self.facility_cursor = 0
                    self.state = "facility"
        elif self.state == "facility":
            self.facility_cursor = (self.facility_cursor + self.direction()) % len(HUB_MENUS[self.facility_index])
            if cancel:
                self.facility_back = "camp"
                self.state = "camp"
            elif confirm:
                facility, option = self.facility_index, self.facility_cursor
                if facility == 3 and option == 1:
                    self.facility_back = "camp"
                    self.state = "camp"
                else:
                    self.facility_back = "facility"
                    if facility == 0:
                        if option == 0:
                            self.overlay, self.info_tab, self.scroll = "info", 0, 0
                        elif option == 1:
                            self.state = "quest_record"
                        elif option == 2:
                            self.state, self.save_choice, self.notice_timer = "save_confirm", 0, 0
                        else:
                            self.overlay = "help"
                    elif facility == 1:
                        if option == 0:
                            self.state, self.archive_page, self.archive_cursor = "archive", 0, 0
                        else:
                            self.state, self.notice_timer = "relearn_character", 0
                    elif facility == 2:
                        self.state = "quest_board" if option == 0 else "pub"
                        self.quest_cursor = self.pub_cursor = 0
                        self.quest_type_cursor = 0
                        self.quest_flavor_page = 0
                    else:
                        self.state, self.shop_cursor = "shop", 0
        elif self.state == "shop":
            self.shop_cursor = (self.shop_cursor + self.direction()) % len(ITEMS)
            if cancel:
                self.state = self.facility_back
            elif confirm:
                item = ITEMS[self.shop_cursor]
                self.tell(self.session.inventory.buy(item, self.session.treasure)[1])
        elif self.state == "pub":
            self.pub_cursor = (self.pub_cursor + self.direction()) % 2
            if cancel or (confirm and self.pub_cursor):
                self.state = self.facility_back
            elif confirm:
                cost = self.session.inventory.data["pub_cost"]
                if self.session.treasure.banked < cost:
                    self.tell(f"{CURRENCY_NAME}が足りません")
                else:
                    self.session.treasure.banked -= cost
                    pool = self.rumors["gameplay" if self.session.rng.random() < self.session.inventory.data["pub_gameplay_weight"] else "flavor"]
                    choices = [line for line in pool if line != self.last_rumor] or pool
                    self.last_rumor = self.session.rng.choice(choices)
                    self.show_field_event(["酒場の噂:", self.last_rumor], return_state="pub")
        elif self.state == "archive":
            if cancel:
                self.state = self.facility_back
            elif confirm:
                self.archive_page = 1 - self.archive_page
            elif self.archive_page:
                self.archive_cursor = (self.archive_cursor + self.direction()) % len(self.session.skills)
        elif self.state == "clear":
            if confirm:
                self.state = "explore"
        elif self.state == "explore":
            if cancel:
                self.state, self.menu_cursor = "menu", 0
                self.notice_timer = 0
            elif confirm:
                if at_b15_elevator(self.dungeon):
                    self.state, self.travel_choice = 'elevator_return', 1
                else:
                    self.quest_or_field_event(self.dungeon.interact, contact=False)
            else:
                dx, dy = self.direction(horizontal=True), self.direction()
                if dx:
                    dy = 0
                if dx or dy:
                    self.player_facing = ("right" if dx > 0 else "left") if dx else ("down" if dy > 0 else "up")
                    previous = self.dungeon.floor, self.dungeon.x, self.dungeon.y
                    event = self.dungeon.move(dx, dy, self.session.debug)
                    if (self.dungeon.floor, self.dungeon.x, self.dungeon.y) != previous:
                        self.quest_or_field_event(lambda: event, contact=True)
                        if self.state == 'explore' and at_b15_elevator(self.dungeon):
                            self.tell('エレベーター: Aで城下町へ帰還')
                    else:
                        self.handle_event(*event)
        elif self.state == "menu":
            self.menu_cursor = (self.menu_cursor + self.direction()) % len(EXPLORATION_MENU)
            if cancel:
                self.state = "explore"
            elif confirm:
                if self.menu_cursor < 2:
                    self.overlay, self.info_tab, self.scroll = "info", self.menu_cursor, 0
                elif self.menu_cursor == 2:
                    self.state, self.item_cursor = "items", 0
                elif self.menu_cursor == 3:
                    self.open_return_skill()
                elif self.menu_cursor == 4:
                    self.overlay = "help"
                elif self.menu_cursor == 6:
                    self.overlay = 'field_quest'
                elif self.can_suspend_game():
                    self.state, self.suspend_choice, self.suspend_error = 'suspend_confirm', 1, ''
                else:
                    self.tell('今は中断できません')
        elif self.state == "items":
            self.item_kind_cursor = (self.item_kind_cursor + self.direction()) % len(ITEMS)
            if cancel:
                self.state = "menu"
                self.notice_timer = 0
            elif confirm:
                item = ITEMS[self.item_kind_cursor]
                if self.session.inventory.counts[item] == 0:
                    self.tell("道具がありません")
                elif item == RETURN_FEATHER:
                    if self.can_use_return_feather():
                        self.state, self.travel_choice = 'feather_return', 1
                    else:
                        self.tell('今は帰還の羽根を使えません')
                else:
                    self.state, self.item_cursor = "item_target", 0
        elif self.state == "item_target":
            self.item_cursor = (self.item_cursor + self.direction()) % 4
            if cancel:
                self.state = "items"
            elif confirm:
                item = ITEMS[self.item_kind_cursor]
                self.tell(self.session.inventory.use(item, self.session.party[self.item_cursor])[1])
        elif self.state == "field_heal":
            self.item_cursor = (self.item_cursor + self.direction()) % 4
            if cancel:
                self.state, self.overlay = self.field_return, "info"
                self.scroll = min(self.scroll, self.info_scroll_limit())
                self.notice_timer = 0
            elif confirm:
                self.use_field_skill(self.item_cursor)

    def use_field_skill(self, target_index):
        result = self.session.field_use(self.field_actor, self.field_skill, target_index)
        if result.used:
            play_cue("mastered" if any("MASTERED!" in line for line in result.messages) else "skill")
        self.tell(result.messages[-1])

    def draw(self):
        if hasattr(self, 'description_scroll'):
            self.description_scroll.begin_frame()
        if self.overlay == 'rescue':
            pyxel.cls(0)
            if self.state == 'camp':
                self.draw_camp()
            elif getattr(self, 'battle', None):
                self.draw_battle()
            self.draw_rescue_notice()
            return
        if self.overlay == 'field_quest':
            pyxel.cls(0)
            self.draw_field_quest()
        elif self.state in TRAVEL_STATES:
            self.draw_travel()
        elif self.state in ('suspend_confirm', 'suspend_busy'):
            pyxel.cls(0)
            self.draw_suspend()
        elif self.state == "title":
            self.draw_title()
        elif self.state == "title_no_save":
            self.draw_title_no_save()
        elif self.state == "title_fade":
            pyxel.cls(0)
        elif self.state == "intro":
            self.draw_intro()
        elif self.state == "hub_preview":
            pyxel.cls(0)
            self.draw_camp()
        elif self.state == "hub_intro":
            self.draw_hub_intro()
        elif self.state in POSTGAME_STATES:
            self.draw_postgame()
        elif self.state in FINAL_EVENT_STATES:
            self.draw_final_event()
        elif self.state == "battle_transition":
            flash = self.battle_transition_frame in BATTLE_TRANSITION_FLASH_FRAMES
            if flash:
                # Brighten existing palette indices for a single frame; no new colors.
                pyxel.pal(0, 2)
                pyxel.pal(1, 3)
                pyxel.pal(2, 3)
            try:
                super().draw()
                draw_pieces(self.battle_transition_image, self.battle_transition_frame)
            finally:
                if flash:
                    pyxel.pal()
        elif self.overlay == "feedback_debug":
            self.draw_feedback_debug()
        elif not self.overlay and self.state in ('guardian_warning', 'guardian_between', 'guardian_after'):
            pyxel.cls(0)
            self.draw_guardians()
        elif not self.overlay and self.state in ("field_event", "quest_board", "quest_type", "quest_preview"):
            self.draw_field_ui()
        elif self.overlay == "treasure_debug":
            self.draw_treasure_debug()
        elif not self.overlay and self.state in ("relearn_character", "relearn_list", "relearn_confirm", "field_return", "return_result",
                                                "quest_thanks", "quest_reward", "quest_record", "save_confirm", "save_result"):
            self.draw_camp_resources()
        elif self.overlay in ("dungeon_debug", "effects"):
            pyxel.cls(0)
            self.draw_dungeon_debug() if self.overlay == "dungeon_debug" else self.draw_effects()
        elif self.overlay == "catalog":
            self.draw_catalog()
        elif self.overlay or self.state not in ("camp", "facility", "archive", "explore", "menu", "items", "item_target", "shop", "pub", "field_heal", "clear", "boss_message", "boss_after"):
            super().draw()
            if self.overlay == "info" and self.info_tab == 1 and self.state in ("explore", "menu"):
                self.footer("左右:人 上下:技 A:使用/頁 B:閉じる")
        else:
            pyxel.cls(0)
            if self.state == "camp":
                self.draw_camp()
            elif self.state == "facility":
                self.draw_facility()
            elif self.state == "archive":
                self.draw_archive()
            elif self.state == "explore":
                self.draw_explore()
            elif self.state == "menu":
                self.draw_menu()
            elif self.state == "items":
                self.draw_items()
            elif self.state == "item_target":
                self.draw_item_target()
            elif self.state == "shop":
                self.draw_shop()
            elif self.state == "pub":
                self.draw_pub()
            elif self.state == "field_heal":
                self.draw_field_heal()
            elif self.state in ("boss_message", "boss_after"):
                self.draw_boss_message()
            else:
                self.draw_clear()

    def draw_camp(self):
        self.title("拠点 / 城下町" + (" DEBUG" if self.session.debug else ""))
        self.draw_banked_trz()
        for i, (name, sprite) in enumerate(zip(HUB_FACILITIES, HUB_ICONS)):
            x, y = HUB_POSITIONS[i]
            if i == self.camp_cursor:
                width = HUB_SELECTION_WIDTHS[i] + (2 if name == 'ELEVATOR' else 0)
                pyxel.rect(x-2, y - 1, width, 18, 1)
                pyxel.rectb(x-2, y - 1, width, 18, 3)
            pyxel.blt(x, y, HUB_IMAGE_BANK, *sprite, 16, 16, 0)
            label = HUB_FACILITY_LABELS[i]
            if name == 'ELEVATOR':
                # The existing selection border supplies the cursor here.
                # Six Japanese glyphs fit beside the icon, without a prefix.
                text(110, y + 5, label, 3 if i == self.camp_cursor else 2)
            else:
                text(x+19, y + 5, (">" if i == self.camp_cursor else " ") + label,
                     3 if i == self.camp_cursor else 2, 18)
        pyxel.blt(94, 20, HUB_IMAGE_BANK, *HUB_PICTURES[self.camp_cursor],
                  HUB_PICTURE_SIZE, HUB_PICTURE_SIZE, 0)
        self.footer("D-PAD:選択 A:入る")

    def draw_facility(self):
        index = self.facility_index
        self.title(HUB_FACILITY_LABELS[index] + " / 拠点")
        self.draw_banked_trz()
        pyxel.blt(94, 20, HUB_IMAGE_BANK, *HUB_PICTURES[index],
                  HUB_PICTURE_SIZE, HUB_PICTURE_SIZE, 0)
        text(6, 22, HUB_DESCRIPTIONS[index], 2, 21)
        for i, label in enumerate(HUB_MENUS[index]):
            y = HUB_MENU_Y + i * HUB_MENU_STEP
            if i == self.facility_cursor:
                pyxel.rect(4, y - 2, 86, 14, 1)
            text(8, y, (">" if i == self.facility_cursor else " ") + HUB_MENU_LABELS[label],
                 3 if i == self.facility_cursor else 2, 21)
        self.footer("D-PAD:選択 A:決定 B:拠点へ")

    def draw_banked_trz(self):
        label = fit(f"{CURRENCY_NAME} {self.session.treasure.banked}", HUB_CURRENCY_WIDTH * 4)
        text(HUB_CURRENCY_RIGHT - text_width(label), HUB_CURRENCY_Y, label, 0,
             HUB_CURRENCY_WIDTH)

    def draw_archive(self):
        skills = list(self.session.skills.values())
        summary = self.session.archive_summary()
        if self.archive_page == 0:
            total = summary["total"]
            discovered = summary["discovered"]
            mastered = summary["mastered"]
            self.title("スキル図鑑")
            text(5, 16, f"DISCOVERED {discovered}/{total}  {discovered * 100 // total}%", 3, 37)
            text(5, 27, f"MASTERED   {mastered}/{total}  {mastered * 100 // total}%", 3, 37)
            text(5, 40, "RARITY       発見  習熟  全", 2, 37)
            for i, rarity in enumerate(("BASIC", "COMMON", "UNCOMMON", "RARE", "LEGEND")):
                row = summary["rarities"].get(rarity, {"total": 0, "discovered": 0,
                                                       "mastered": 0})
                text(7, 51 + i * 10,
                     f"{rarity:8} {row['discovered']:2}    {row['mastered']:2}   {row['total']:2}",
                     3 if rarity == "LEGEND" else 2, 37)
            self.footer("A:技一覧 B:戻る")
            return
        self.title(f"スキル一覧 {self.archive_cursor + 1}/{len(skills)}")
        start = max(0, min(self.archive_cursor - 4, len(skills) - 7))
        for i, skill in enumerate(skills[start:start + 7]):
            selected = start + i == self.archive_cursor
            known = skill.id in self.session.discovered_skills
            mastered = skill.id in self.session.mastered_skills
            label = skill.name if known else "????????"
            marker = ("D" if known else "-") + ("M" if mastered else "-")
            if selected:
                pyxel.rect(2, 14 + i * 10, 156, 9, 1)
            text(4, 15 + i * 10,
                 f"{start + i + 1:02} {marker} {label}", 3 if selected else 2, 37)
        selected = skills[self.archive_cursor]
        category = CATEGORIES[selected.skill_type] if selected.id in self.session.discovered_skills else "????"
        text(5, 90, "TYPE " + category + "  D=発見 M=習熟", 2, 37)
        if selected.id in self.session.mastered_skills:
            text(5, 100, "MASTERED: " + selected.mastery_label, 2, 37)
        self.footer("上下:技 A:集計 B:戻る")

    def draw_explore(self):
        d = self.dungeon
        width, height = d.map_bounds(d.floor)
        self.title(f"B{d.floor + 1}F 薬{d.potions} 未確定{CURRENCY_NAME}{d.treasure.unbanked}" + (" DEBUG" if self.session.debug else ""))
        camera_x = d.x * TILE_SIZE + TILE_SIZE // 2 - MAP_WIDTH // 2
        camera_y = d.y * TILE_SIZE + TILE_SIZE // 2 - MAP_HEIGHT // 2
        source_x = max(0, camera_x)
        source_y = max(0, camera_y)
        source_right = min(width * TILE_SIZE, camera_x + MAP_WIDTH)
        source_bottom = min(height * TILE_SIZE, camera_y + MAP_HEIGHT)
        draw_width = max(0, source_right - source_x)
        draw_height = max(0, source_bottom - source_y)
        pyxel.clip(MAP_X, MAP_Y, MAP_WIDTH, MAP_HEIGHT)
        if draw_width and draw_height:
            pyxel.bltm(MAP_X + source_x - camera_x,
                       MAP_Y + source_y - camera_y,
                       d.maps[d.floor], source_x, source_y,
                       draw_width, draw_height)
        # Candidate markers stay editable in Tilemap but look like ordinary floor.
        if d.floor in d.activated_switches:
            for source, replacement in ((TILE_SWITCH, TILE_SWITCH_ON), (TILE_DOOR, TILE_DOOR_OPEN)):
                for x, y in d.positions(d.floor, source):
                    u, v = replacement
                    pyxel.blt(MAP_X + x * TILE_SIZE - camera_x,
                              MAP_Y + y * TILE_SIZE - camera_y,
                              MAP_IMAGE_BANK, u * TILE_SIZE, v * TILE_SIZE,
                              TILE_SIZE, TILE_SIZE)
        for x, y in d.positions(d.floor, TILE_QUEST):
            u, v = d.floor_appearance(d.floor, x, y)
            pyxel.blt(MAP_X + x * TILE_SIZE - camera_x,
                      MAP_Y + y * TILE_SIZE - camera_y,
                      MAP_IMAGE_BANK, u * TILE_SIZE, v * TILE_SIZE,
                      TILE_SIZE, TILE_SIZE)
        for floor, x, y in d.opened:
            if floor == d.floor:
                u, v = TILE_CHEST_OPEN
                pyxel.blt(MAP_X + x * TILE_SIZE - camera_x,
                          MAP_Y + y * TILE_SIZE - camera_y,
                          MAP_IMAGE_BANK, u * TILE_SIZE, v * TILE_SIZE,
                          TILE_SIZE, TILE_SIZE)
        if d.floor in d.defeated_bosses:
            u, v = TILE_BOSS_CLEAR
            x, y = d.boss_positions[d.floor]
            pyxel.blt(MAP_X + x * TILE_SIZE - camera_x,
                      MAP_Y + y * TILE_SIZE - camera_y,
                      MAP_IMAGE_BANK, u * TILE_SIZE, v * TILE_SIZE,
                      TILE_SIZE, TILE_SIZE)
        self.draw_dragon_symbol(camera_x,camera_y)
        for x, y in self.exploration.visible_points():
            bank, u, v = QUEST_SYMBOLS[self.exploration.active_quest['type']]
            draw_quest_symbol(pyxel, MAP_X + x * TILE_SIZE - camera_x,
                              MAP_Y + y * TILE_SIZE - camera_y, bank, u, v)
        if d.floor == 14 and d.finale.demon_defeated and 14 in d.defeated_bosses:
            x, y = b15_elevator_point(d)
            sx, sy = MAP_X + x*TILE_SIZE-camera_x, MAP_Y + y*TILE_SIZE-camera_y
            u, v = d.floor_appearance(14, x, y)
            pyxel.blt(sx, sy, MAP_IMAGE_BANK, u*TILE_SIZE, v*TILE_SIZE,
                      TILE_SIZE, TILE_SIZE)
            pyxel.blt(sx, sy, *B15_ELEVATOR_SPRITE, 0)
        # Map-only facing sprites in Image Bank 0 of game.pyxres.
        if d.floor == 14 and d.finale.guardians_defeated:
            x, y = d.find(14, TILE_GUARDIAN)
            u, v = d.floor_appearance(14, x, y)
            pyxel.blt(MAP_X + x * TILE_SIZE - camera_x, MAP_Y + y * TILE_SIZE - camera_y,
                      MAP_IMAGE_BANK, u * TILE_SIZE, v * TILE_SIZE, TILE_SIZE, TILE_SIZE)
        player_x = MAP_X + MAP_WIDTH // 2 - PLAYER_WIDTH // 2
        player_y = MAP_Y + MAP_HEIGHT // 2 - PLAYER_HEIGHT // 2
        pyxel.blt(player_x, player_y, 0, *PLAYER_SPRITES[self.player_facing],
                  PLAYER_WIDTH, PLAYER_HEIGHT, 0)
        pyxel.clip()
        for i, actor in enumerate(self.session.party):
            y = 15 + i * 21
            text(102, y, actor.name, 3 if actor.alive else 1, 10)
            draw_status_icons(pyxel, actor, 148, y, limit=1)
            text(102, y + 9, f"{actor.hp}/{actor.max_hp}" if actor.alive else "戦闘不能", 2, 14)
        text(102, 100, f"{d.x},{d.y}", 1, 14)
        self.footer("D-PAD:移動 A:調べる B:メニュー")

    def draw_menu(self):
        self.title(f"{self.dungeon.floor + 1}F / 探索メニュー")
        for i, label in enumerate(EXPLORATION_MENU):
            if label == 'return':
                label = self.session.skills['return'].name
            text(12, 17 + i * 11, (">" if i == self.menu_cursor else " ") + label, 3, 34)
        text(8, 99, f"帰還で未確定{CURRENCY_NAME}を確保", 2, 36)
        self.footer("D-PAD:選択 A:決定 B:探索へ")

    def draw_field_quest(self):
        """Read-only contract summary; never expose hidden points or RNG."""
        self.title('クエスト')
        quest = self.exploration.active_quest
        if quest is None:
            text(12, 44, '受注中のクエストはありません', 3, 34)
        else:
            text(12, 24, self.exploration.quest_name(), 3, 34)
            text(12, 42, f"対象：B{quest['target_floor']}F", 3, 34)
            text(12, 60, f"進捗：{quest['progress']}/{quest['required_count']}", 3, 34)
            if quest['completed']:
                text(12, 85, '拠点に戻って報告', 2, 34)
        self.footer('B:戻る')

    def draw_items(self):
        self.title("道具 / 探索中")
        for i, item in enumerate(ITEMS):
            text(6, 23 + i * 17, (">" if i == self.item_kind_cursor else " ") +
                 f"{self.session.inventory.label(item)} x{self.session.inventory.counts[item]}", 3 if i == self.item_kind_cursor else 2, 37)
        hint = self.session.inventory.description(ITEMS[self.item_kind_cursor])
        text(6, 94, hint, 2, 37)
        self.footer("上下:選択 A:使用 B:戻る")

    def draw_item_target(self):
        item = ITEMS[self.item_kind_cursor]
        self.title(self.session.inventory.label(item) + " / 誰に使う?")
        for i, actor in enumerate(self.session.party):
            y = 34 + i * 15
            if i == self.item_cursor:
                pyxel.rect(3, y - 1, 153, 10, 1)
            text(5, y, (">" if i == self.item_cursor else " ") + actor.name, 3, 11)
            draw_status_icons(pyxel, actor, 54, y, limit=1)
            text(67, y, f"HP {actor.hp}/{actor.max_hp}", 2, 22)
        text(5, 99, "無効な対象には消費しません", 2, 37)
        self.footer("上下:選択 A:使う B:戻る")

    def draw_shop(self):
        self.title("ショップ / 道具購入")
        text(5, 16, f"{CURRENCY_NAME} {self.session.treasure.banked}", 3, 37)
        for i, item in enumerate(ITEMS):
            row = self.session.inventory.data["items"][item]
            text(5, 34 + i * 17, (">" if i == self.shop_cursor else " ") +
                 f"{self.session.inventory.label(item)} {row['price']} {CURRENCY_NAME} x{self.session.inventory.counts[item]}/9",
                 3 if i == self.shop_cursor else 2, 37)
        self.footer("上下:選択 A:購入 B:戻る")

    def draw_pub(self):
        self.title("パブ / 噂を聞く")
        text(8, 24, f"{CURRENCY_NAME} {self.session.treasure.banked}", 3, 35)
        text(8, 39, f"噂を聞く? {self.session.inventory.data['pub_cost']} {CURRENCY_NAME}", 2, 35)
        for i, label in enumerate(("YES", "NO")):
            text(12, 61 + i * 16, (">" if i == self.pub_cursor else " ") + label, 3, 20)
        self.footer("上下:選択 A:決定 B:戻る")

    def draw_clear(self):
        self.title("アムリタ取得")
        text(12, 28, "デーモンを倒した!", 3, 34)
        text(12, 45, f"{self.session.completed}戦 / {self.session.wins}勝", 2, 34)
        text(12, 60, f"{CURRENCY_NAME} 確定{self.session.treasure.banked} 未確定{self.session.treasure.unbanked}", 2, 34)
        text(12, 78, "Dで育成結果を確認できます", 2, 34)
        text(12, 93, f"依頼の成果と{CURRENCY_NAME}を持ち帰ろう", 2, 34)
        self.footer("A:探索に戻る")

    def draw_field_heal(self):
        actor = self.session.party[self.field_actor]
        skill = self.session.skills[self.field_skill]
        self.title(f"{skill.name} {actor.skill_uses.get(skill.id, 0)}/{actor.max_uses(skill)}")
        text(5, 17, f"{actor.name} / 誰を{'治療' if skill.effect == 'cure' else '回復'}?", 2, 37)
        for i, target in enumerate(self.session.party):
            y = 34 + i * 15
            text(5, y, (">" if i == self.item_cursor else " ") + target.name, 3, 14)
            text(67, y, f"HP {target.hp}/{target.max_hp}", 2, 22)
        hint = self.cure_target_hint(skill, [self.session.party[self.item_cursor]])
        text(5, 99, hint + " / 消費なし" if hint else "回数を消費・探索使用は成長なし", 2, 37)
        self.footer("上下:対象 A:使用 B:技一覧へ")

    def draw_result(self):
        super().draw_result()
        if self.battle.outcome == "DEFEAT":
            self.title("PARTY DEFEATED / 全滅")

    def draw_catalog(self):
        pyxel.cls(0)
        skills = list(self.session.skills.values())
        self.title(f"{self.session.party[self.info_character].name} 全技 {self.catalog_cursor + 1}/{len(skills)}")
        start = max(0, self.catalog_cursor - 5)
        for i, skill in enumerate(skills[start:start + 6]):
            selected = start + i == self.catalog_cursor
            text(5, 16 + i * 9, (">" if selected else " ") + skill.name, 3 if selected else 2, 37)
        self.skill_details(self.session.party[self.info_character], skills[self.catalog_cursor])
        self.footer("C:取得 V:残1 B:発見 M:習熟 R:再")

    def open_return_skill(self, actor_index=0, from_skills=False):
        """Both exploration entries use the existing RETURN actor picker."""
        self.return_back_state = self.state if from_skills else "menu"
        self.return_back_overlay = "info" if from_skills else None
        self.state, self.overlay, self.item_cursor = "field_return", None, actor_index
        self.notice_timer = 0

    def update_camp_resources(self):
        confirm, cancel = self.confirm(), self.cancel()
        if self.state == "save_confirm":
            self.save_choice = (self.save_choice + self.direction()) % 2
            if cancel or (confirm and self.save_choice):
                self.state = 'facility'
            elif confirm:
                try:
                    self.save_manager.save(self)
                    self.save_message = 'セーブしました。'
                except Exception as error:
                    print('SAVE failed:', repr(error))
                    self.save_message = str(error) if isinstance(error, SaveError) else 'セーブできませんでした。'
                self.state = 'save_result'
        elif self.state == "save_result":
            if confirm or cancel:
                self.state, self.notice_timer = 'facility', 0
        elif self.state == "quest_record":
            if cancel:
                self.state, self.notice_timer = "facility", 0
            elif confirm and self.dungeon.completion.main_game_cleared:
                self.postgame_state('completion_record')
        elif self.state == "quest_thanks":
            if confirm:
                pages = self.quest_thanks_pages()
                if self.quest_thanks_page + 1 < len(pages):
                    self.quest_thanks_page += 1
                else:
                    self.quest_completion_receipt = deepcopy(self.exploration.active_quest)
                    self.exploration.finalize_quest_completion()
                    self.state = "quest_reward"
        elif self.state in ("return_result", "quest_reward"):
            if confirm:
                self.state, self.notice_timer = "camp", 0
                if self.camp_offer_pending and self.dungeon.finale.can_offer_amrita:
                    self.show_amrita_offer()
        elif self.state == "field_return":
            if self.dungeon.finale.guardian_index is not None:
                self.tell(self.dungeon.finale.data['return_locked'][0])
                return
            self.item_cursor = (self.item_cursor + self.direction()) % 4
            if cancel:
                self.state, self.overlay = self.return_back_state, self.return_back_overlay
                self.scroll = min(self.scroll, self.info_scroll_limit())
                self.notice_timer = 0
            elif confirm:
                try:
                    self.return_lines = self.session.field_return(self.item_cursor)
                except ValueError as error:
                    self.tell(str(error))
                    return
                play_cue("mastered" if any("MASTERED!" in line for line in self.return_lines) else "skill")
                self.safe_return(self.return_lines)
        elif self.state == "relearn_character":
            self.info_character = (self.info_character + self.direction()) % 4
            if cancel:
                self.state = self.facility_back
            elif confirm:
                self.state, self.relearn_cursor = "relearn_list", 0
        elif self.state == "relearn_list":
            candidates = self.session.relearn_candidates()
            if cancel:
                self.state = "relearn_character"
            elif candidates:
                self.relearn_cursor = (self.relearn_cursor + self.direction()) % len(candidates)
                if confirm:
                    self.relearn_skill = candidates[self.relearn_cursor].id
                    self.state, self.notice_timer = "relearn_confirm", 0
        elif self.state == "relearn_confirm":
            if cancel:
                self.state, self.notice_timer = "relearn_list", 0
            elif confirm:
                try:
                    message = self.session.relearn(self.info_character, self.relearn_skill)
                except ValueError as error:
                    self.tell(str(error))
                    return
                if self.session.pending_replacements:
                    # Use the existing replacement/decline UI and its return route.
                    self.debug_return_state, self.debug_return_overlay = "relearn_list", None
                    self.state, self.overlay = "replace", None
                    self.replacement_cursor, self.replacement_confirm = 0, False
                    self.notice_timer = 0
                else:
                    self.state = "relearn_list"
                    self.tell(message)

    def draw_camp_resources(self):
        pyxel.cls(0)
        s = self.session
        if self.state in ('save_confirm', 'save_result'):
            self.title('セーブ / ギルド')
            self.draw_banked_trz()
            if self.state == 'save_confirm':
                text(12, 30, '保存しますか？', 3, 34)
                for i, label in enumerate(('はい', 'いいえ')):
                    text(18, 58 + i * 18, ('> ' if self.save_choice == i else '  ') + label, 3, 30)
                self.footer('上下:選択 A:決定 B:戻る')
            else:
                for i, line in enumerate(wrap_lines([self.save_message], 34)[:5]):
                    text(12, 36 + i * 10, line, 3, 34)
                self.footer('A/B:戻る')
        elif self.state == "quest_record":
            self.title("クエスト記録")
            text(5, 18, "種別", 2, 8)
            text(42, 18, "CLEAR", 2, 8)
            text(83, 18, "達成数", 2, 8)
            text(126, 18, "達成率", 2, 8)
            records = self.exploration.quest_record()
            for i, kind in enumerate(QUEST_TYPES):
                row, y = records[kind], 35 + i * 15
                text(5, y, QUEST_NAMES[kind], 3, 8)
                text(42, y, row['clears'], 3, 8)
                text(83, y, f"{row['completed']}/{row['total']}", 3, 8)
                text(126, y, f"{row['percent']}%", 3, 8)
            total = records['total']
            text(5, 85, "TOTAL", 3, 8)
            text(83, 85, f"{total['completed']}/{total['total']}", 3, 8)
            text(126, 85, f"{total['percent']}%", 3, 8)
            text(5, 99, "COMPLETE!" if total['percent'] == 100 else "再クリアもCLEARに加算", 2, 37)
            self.footer("A:クリア記録 B:ギルドへ" if self.dungeon.completion.main_game_cleared else "B:ギルドへ戻る")
        elif self.state == "quest_thanks":
            self.title("依頼人からのお礼")
            text(6, 19, self.exploration.quest_flavor()['requester'], 3, 37)
            for i, line in enumerate(self.quest_thanks_pages()[self.quest_thanks_page]):
                text(7, 36 + i * 9, line, 2, 36)
            self.footer("A:次へ")
        elif self.state == "quest_reward":
            self.title("クエスト完了")
            q = self.quest_completion_receipt
            text(6, 19, self.exploration.quest_name(q), 3, 37)
            text(6, 34, f"{q['reward']} {CURRENCY_NAME}を受け取った", 3, 37)
            text(6, 49, f"{CURRENCY_NAME}: {s.treasure.banked}", 3, 37)
            text(6, 64, f"持ち帰り {self.return_secured} {CURRENCY_NAME} / 全員HP回復", 2, 37)
            for i, line in enumerate(wrap_lines(self.return_lines, 36)[:3]):
                text(6, 79 + i * 9, line, 2, 36)
            self.footer("A:拠点へ")
        elif self.state == "return_result":
            self.title("拠点へ帰還")
            text(6, 19, f"{self.return_secured} {CURRENCY_NAME}を確保", 3, 37)
            text(6, 32, f"{CURRENCY_NAME}: {s.treasure.banked}", 3, 37)
            text(6, 45, f"未確定{CURRENCY_NAME}: 0 / 全員HP回復", 2, 37)
            for i, line in enumerate(wrap_lines(self.return_lines, 36)[:5]):
                text(6, 59 + i * 9, line, 2, 37)
            self.footer("A:拠点へ")
        elif self.state in ("relearn_character", "field_return"):
            returning = self.state == "field_return"
            self.title(s.skills['return'].name + " / 帰還スキル" if returning else "スキル再取得 / 人を選ぶ")
            text(5, 16, f"未確定{CURRENCY_NAME} {s.treasure.unbanked}を確保" if returning else f"{CURRENCY_NAME} {s.treasure.banked}", 2, 37)
            for i, actor in enumerate(s.party):
                cursor = self.item_cursor if returning else self.info_character
                text(5, 32 + i * 16, (">" if i == cursor else " ") + actor.name, 3, 20)
                if returning:
                    uses = sum(actor.skill_uses.get(sid, 0) for sid in actor.skills if s.skills[sid].effect == 'return')
                    label = (f"USES {uses}" if uses else "使用不可") if actor.alive else "戦闘不能"
                else:
                    label = f"技{len(actor.skills)}/{s.settings['skill_slots']}"
                text(94, 32 + i * 16, label, 2, 16)
            if returning:
                text(5, 99, "所持する技のUsesを1回消費", 2, 37)
            self.footer("上下:人 A:使用 B:戻る" if returning else "上下:人 A:技選択 B:戻る")
        elif self.state == "relearn_list":
            actor = s.party[self.info_character]
            candidates = s.relearn_candidates()
            self.title(actor.name + " / スキル再取得")
            text(5, 16, f"{CURRENCY_NAME} {s.treasure.banked} 基本/通常/RARE補助", 2, 37)
            start = max(0, self.relearn_cursor - 5)
            for i, skill in enumerate(candidates[start:start + 6]):
                selected = start + i == self.relearn_cursor
                text(5, 30 + i * 11, (">" if selected else " ") + skill.name, 3 if selected else 2, 23)
                text(101, 30 + i * 11, "所持中" if skill.id in actor.skills else f"{skill.relearn_cost} {CURRENCY_NAME}", 2, 14)
            if candidates:
                skill = candidates[self.relearn_cursor]
                text(5, 100, f"再取得{actor.relearn_uses(skill)}/{actor.next_max_uses(skill)}回 / {skill.relearn_cost} {CURRENCY_NAME}", 2, 37)
            else:
                text(5, 35, "再取得できる発見済み技なし", 2, 37)
            self.footer("上下:技 A:確認 B:人選択")
        else:
            actor = s.party[self.info_character]
            skill = s.skills[self.relearn_skill]
            self.title("スキル再取得の確認")
            text(5, 20, actor.name + " / " + skill.name, 3, 37)
            text(5, 36, f"費用 {skill.relearn_cost} {CURRENCY_NAME} / 所持{s.treasure.banked}", 2, 37)
            text(5, 50, f"使用回数 {actor.relearn_uses(skill)}/{actor.next_max_uses(skill)}", 3, 37)
            if skill.effect in ('damage', 'drain'):
                bonus = ' / MASTER x1.2' if actor.next_power_multiplier(skill) > 1 else ''
                text(5, 64, f"予定威力 {skill.power(actor, next_copy=True)}{bonus}", 3, 37)
            text(5, 80, "満杯なら入れ替えを選択", 2, 37)
            text(5, 96, f"取り消しでは{CURRENCY_NAME}を消費しない", 2, 37)
            self.footer("A:再取得 B:取り消し")

    def quest_thanks_pages(self):
        lines = wrap_lines(self.exploration.quest_flavor()['complete_lines'], 36)
        return [lines[i:i + 7] for i in range(0, len(lines), 7)]

    def show_field_event(self, lines, return_state="explore"):
        self.field_lines = wrap_lines(lines, 36)
        self.field_page, self.notice_timer = 0, 0
        self.field_after = return_state
        self.state, self.overlay = "field_event", None

    def update_field_ui(self):
        confirm, cancel = self.confirm(), self.cancel()
        if self.state == "field_event":
            if not confirm:
                return
            if (self.field_page + 1) * 8 < len(self.field_lines):
                self.field_page += 1
            elif self.session.pending_replacements:
                self.debug_return_state, self.debug_return_overlay = self.field_after, None
                self.state = "replace"
                self.replacement_cursor, self.replacement_confirm = 0, False
            else:
                self.state = self.field_after
            return
        e = self.exploration
        if self.state == "quest_preview":
            if cancel:
                e.decline_preview()
                self.state, self.notice_timer = "quest_type", 0
                return
            pages = self.quest_flavor_pages(e.pending_quest)
            if self.quest_flavor_page + 1 < len(pages):
                if confirm:
                    self.quest_flavor_page += 1
                return
            self.quest_offer_cursor = (self.quest_offer_cursor + self.direction()) % 2
            if confirm:
                if self.quest_offer_cursor:
                    e.decline_preview()
                    self.state, self.notice_timer = "quest_type", 0
                else:
                    try:
                        message = e.accept_preview()
                        self.state, self.quest_flavor_page = "quest_board", 0
                        self.tell(message)
                    except ValueError as error:
                        self.tell(str(error))
            return
        if cancel:
            self.state = "quest_board" if self.state == "quest_type" else self.facility_back
            self.notice_timer = 0
            return
        if e.active_quest:
            if confirm:
                pages = self.quest_flavor_pages()
                if len(pages) > 1:
                    self.quest_flavor_page = (self.quest_flavor_page + 1) % len(pages)
                    self.notice_timer = 0
                else:
                    self.tell(e.message('already_active'))
            return
        if self.state == "quest_board":
            self.quest_cursor = (self.quest_cursor + self.direction()) % len(e.quest_data['levels'])
            if confirm:
                row = e.quest_data['levels'][self.quest_cursor]
                if e.unlocked(row):
                    self.state, self.quest_type_cursor, self.notice_timer = "quest_type", 0, 0
                else:
                    self.tell(f"B{row['gate']}Fボス撃破でLv{row['level']}解放")
        else:
            self.quest_type_cursor = (self.quest_type_cursor + self.direction()) % len(QUEST_TYPES)
            if confirm:
                try:
                    level = e.quest_data['levels'][self.quest_cursor]['level']
                    e.preview_quest(level, QUEST_TYPES[self.quest_type_cursor])
                    self.state, self.notice_timer = "quest_preview", 0
                    self.quest_flavor_page = self.quest_offer_cursor = 0
                except ValueError as error:
                    self.tell(str(error))

    def quest_flavor_pages(self, quest=None):
        lines = wrap_lines(self.exploration.quest_flavor(quest)['lines'], QUEST_FLAVOR_MAX_CHARS)
        return [lines[i:i + QUEST_FLAVOR_LINES_PER_PAGE]
                for i in range(0, len(lines), QUEST_FLAVOR_LINES_PER_PAGE)]

    def draw_field_ui(self):
        pyxel.cls(0)
        if self.state == "field_event":
            self.title("酒場の噂" if self.field_after == 'pub' else "探索 / 調査と発見")
            pyxel.rectb(3, 17, 154, 84, 2)
            for i, line in enumerate(self.field_lines[self.field_page * 8:(self.field_page + 1) * 8]):
                text(7, 24 + i * 9, line, 3, 36)
            self.footer("A:次へ")
            return
        self.title("クエスト / 依頼")
        e = self.exploration
        preview = self.state == "quest_preview"
        q = e.pending_quest if preview else e.active_quest
        if q:
            text(5, 15, e.quest_name(q) + (" / 受注確認" if preview else ""), 3, 37)
            pages = self.quest_flavor_pages(q)
            for i, line in enumerate(pages[self.quest_flavor_page % len(pages)]):
                text(7, 28 + i * QUEST_FLAVOR_LINE_HEIGHT, line, 2, QUEST_FLAVOR_MAX_CHARS)
            text(7, 58, "― " + e.quest_flavor(q)['requester'], 2, 36)
            text(5, 71, f"対象 B{q['target_floor']}F / {q['progress']} / {q['required_count']}", 3, 37)
            text(5, 83, f"報酬 {q['reward']} {CURRENCY_NAME}" + (" / 安全帰還" if preview else ""), 3, 37)
            if preview:
                if self.quest_flavor_page + 1 < len(pages):
                    self.footer("A:依頼文の続き B:受注しない")
                else:
                    for i, label in enumerate(("受注する", "受注しない")):
                        selected = i == self.quest_offer_cursor
                        text(5, 94 + i * 9, (">" if selected else " ") + label, 3 if selected else 2, 37)
                    self.footer("上下:選択 A:決定 B:戻る")
            else:
                text(5, 98, "目的達成・安全帰還で報酬" if q['completed'] else "安全帰還で報酬 / 全滅で進行失う", 2, 37)
                self.footer("A:依頼文の続き B:戻る" if len(pages) > 1 else "受注中 / B:戻る")
        elif self.state == "quest_type":
            row = e.quest_data['levels'][self.quest_cursor]
            level = row['level']
            text(5, 19, f"Lv{level} B{row['floors'][0]}～{row['floors'][1]}F / 種別", 3, 37)
            for i, kind in enumerate(QUEST_TYPES):
                selected = i == self.quest_type_cursor
                reward = e.quest_data['rewards'][kind][str(level)]
                text(5, 36 + i * 19, (">" if selected else " ") + QUEST_NAMES[kind], 3 if selected else 2, 15)
                text(85, 36 + i * 19, f"{reward} {CURRENCY_NAME}", 2, 17)
            text(5, 98, "安全帰還で報酬 / 同時1件", 2, 37)
            self.footer("上下:種別 A:依頼文 B:Lv選択")
        else:
            text(5, 19, "クエストLvを選ぶ", 3, 37)
            levels = e.quest_data['levels']
            for i, row in enumerate(levels):
                selected = i == self.quest_cursor
                label = f"Lv{row['level']} B{row['floors'][0]}～{row['floors'][1]}F"
                if not e.unlocked(row):
                    label += " 未解放"
                text(5, 36 + i * 19, (">" if selected else " ") + label, 3 if selected else 2, 37)
            row = levels[self.quest_cursor]
            hint = "解放済み / 同時受注1件" if e.unlocked(row) else f"B{row['gate']}Fボス撃破でLv{row['level']}解放"
            text(5, 98, hint, 2, 37)
            self.footer("上下:Lv A:種別選択 B:戻る")

    def quest_or_field_event(self, field_event, contact):
        if dragon_here(self.dungeon):
            self.dragon_warning()
            return
        if self.exploration.hunt_here():
            self.begin_encounter(quest_hunt=True, animate=contact)
            return
        was_completed = self.exploration.surveyed
        lines = self.exploration.investigate()
        if lines:
            if not was_completed and self.exploration.surveyed:
                self.audio.play_se('se_quest_complete')
            self.show_field_event(lines)
        else:
            self.handle_event(*field_event())

    def feedback_options(self):
        rewards = self.dungeon.exploration_settings["CHEST_REWARD_TABLE"]["NORMAL"]
        labels = {"TREASURE": CURRENCY_NAME, "POTION": self.session.inventory.label('POTION'),
                  "SKILL_CHANCE": "閃き抽選", "TRAP": "罠", "EMPTY": "空の箱"}
        options = [(f"宝箱: {labels[r['kind']]} {r.get('amount', '')}", r) for r in rewards]
        options += [("RARE宝箱を足元に生成", "rare"), ("毒沼ダメージ", "poison"),
                    ("落とし穴をテスト", "pit")]
        options += [(f"探索Lv{i} 強制受注", i) for i in (1, 2, 3)]
        return options + [("調査地点へ移動", "warp"), ("調査完了ON/OFF", "survey"),
                          ("選択した人を戦闘不能", "ko"), (self.session.skills['revive'].name + "を取得", "revive"),
                          (self.session.inventory.label('PHOENIX ASH') + "を1個取得", "ash"),
                          (self.session.inventory.label('POTION') + "を1個取得", "potion"),
                          ("全アイテムを9個に", "max_items"), ("泉へ移動", "spring"),
                          ("酒場へ", "pub"), (f"確定{CURRENCY_NAME}+10", "bank10")]

    def update_feedback_debug(self):
        if self.pressed(pyxel.KEY_X, pyxel.KEY_ESCAPE):
            self.overlay = None
            return
        options = self.feedback_options()
        self.feedback_cursor = (self.feedback_cursor + self.direction()) % len(options)
        self.info_character = (self.info_character + self.direction(horizontal=True)) % 4
        if not self.pressed(pyxel.KEY_Z, pyxel.KEY_RETURN):
            return
        action = options[self.feedback_cursor][1]
        d, e = self.dungeon, self.exploration
        if isinstance(action, dict):
            previous = self.state
            self.handle_event(*d.grant_chest(action))
            if self.state == "field_event":
                self.field_after = previous
        elif action == "rare":
            if self.state != "explore" or d.tile(d.floor, d.x, d.y) not in FLOOR_TILES or e.target == (d.floor, d.x, d.y):
                self.tell("探索中の通常の床で使ってください")
                return
            d.maps[d.floor].pset(d.x, d.y, TILE_RARE_CHEST)
            d.opened.discard((d.floor, d.x, d.y))
            d.chest_loot.pop((d.floor, d.x, d.y), None)
            self.overlay = None
            self.tell("RARE宝箱を配置。Zで開く")
        elif action == "ko":
            actor = self.session.party[self.info_character]
            if not actor.alive:
                self.tell(f"{actor.name} はすでに戦闘不能")
            elif sum(c.alive for c in self.session.party) <= 1:
                self.tell("最後の生存者は倒せません")
            else:
                actor.hp = 0
                self.tell(f"DEBUG: {actor.name} 戦闘不能")
        elif action == "revive":
            try:
                self.tell(self.session.debug_acquire("revive", self.info_character)[-1])
                if self.session.pending_replacements:
                    self.debug_return_state, self.debug_return_overlay = self.state, "feedback_debug"
                    self.state, self.overlay = "replace", None
                    self.replacement_cursor, self.replacement_confirm = 0, False
            except ValueError as error:
                self.tell(str(error))
        elif action == "ash":
            label = self.session.inventory.label('PHOENIX ASH')
            self.tell(label + " +1" if self.session.inventory.add("PHOENIX ASH") else label + "は満杯")
        elif action == "potion":
            label = self.session.inventory.label('POTION')
            self.tell(label + " +1" if self.session.inventory.add("POTION") else label + "は満杯")
        elif action == "max_items":
            for item in self.session.inventory.counts:
                self.session.inventory.counts[item] = 9
            self.tell("DEBUG: 全アイテム9個")
        elif action == "spring":
            if self.state != "explore":
                self.tell("探索中に使ってください")
            else:
                from .tiles import TILE_HEAL_POINT
                positions = d.positions(d.floor, TILE_HEAL_POINT)
                if positions:
                    d.x, d.y = positions[0]
                    self.overlay = None
                    self.tell("泉へ移動。Zで調べる")
                else:
                    self.tell("この階に泉はありません")
        elif action == "pub":
            self.state, self.overlay, self.pub_cursor = "pub", None, 0
        elif action == "bank10":
            self.session.treasure.banked += 10
            self.tell(f"DEBUG: 確定{CURRENCY_NAME}+10")
        elif action in ("poison", "pit"):
            if self.state != "explore":
                self.tell("探索中に試してください")
                return
            self.handle_event(*d.fall_in_pit() if action == "pit" else ("poison", "DEBUG毒沼"))
        elif isinstance(action, int):
            e.active, e.target, e.surveyed = None, None, False
            e.completed.discard(action)
            self.tell(e.accept(action, debug=True))
        elif e.active:
            if action == "warp":
                d.floor, d.x, d.y = e.target
                self.state, self.overlay = "explore", None
                d.reset_encounter()
                self.tell(e.hint() or "DEBUG: 調査地点へ移動")
            else:
                e.surveyed = not e.surveyed
                self.tell("調査完了 " + ("ON" if e.surveyed else "OFF"))
        else:
            self.tell("先にクエストを受注してください")

    def draw_feedback_debug(self):
        pyxel.cls(0)
        self.title("DEBUG / 探索フィードバック")
        options = self.feedback_options()
        start = max(0, self.feedback_cursor - 5)
        for i, (label, _) in enumerate(options[start:start + 6]):
            text(5, 17 + i * 12, (">" if start + i == self.feedback_cursor else " ") + label, 3, 37)
        target = self.exploration.target
        label = f"調査 B{target[0] + 1}F ({target[1]},{target[2]})" if target else "調査対象なし"
        text(5, 98, label + " / " + self.session.party[self.info_character].name, 2, 37)
        self.footer("左右:人 上下:選択 Z:実行 X:閉じる")

    def update_treasure_debug(self):
        if self.pressed(pyxel.KEY_X, pyxel.KEY_ESCAPE):
            self.overlay = None
            return
        self.treasure_cursor = (self.treasure_cursor + self.direction()) % 5
        self.info_character = (self.info_character + self.direction(horizontal=True)) % 4
        if not self.pressed(pyxel.KEY_Z, pyxel.KEY_RETURN):
            return
        s = self.session
        if self.treasure_cursor == 0:
            s.treasure.unbanked += 5
        elif self.treasure_cursor == 1:
            s.treasure.banked += 5
        elif self.treasure_cursor == 2:
            s.treasure.unbanked = 0
        elif self.treasure_cursor == 3:
            try:
                self.tell(s.debug_acquire("return", self.info_character)[-1])
            except ValueError as error:
                self.tell(str(error))
            if s.pending_replacements:
                self.debug_return_state, self.debug_return_overlay = self.state, "treasure_debug"
                self.state, self.overlay = "replace", None
                self.replacement_cursor, self.replacement_confirm = 0, False
                self.notice_timer = 0
        elif self.state == "camp":
            self.state, self.overlay = "relearn_character", None
        else:
            self.tell("再習得は拠点で行います。")

    def draw_treasure_debug(self):
        pyxel.cls(0)
        s = self.session
        self.title(f"DEBUG / {CURRENCY_NAME}と帰還")
        text(5, 16, f"未確定{s.treasure.unbanked} / 確定{s.treasure.banked}", 3, 37)
        for i, label in enumerate((f"未確定{CURRENCY_NAME} +5", f"確定{CURRENCY_NAME} +5", f"未確定{CURRENCY_NAME}を0", self.session.skills['return'].name + "を取得", "拠点の再習得を開く")):
            text(5, 31 + i * 12, (">" if i == self.treasure_cursor else " ") + label, 3, 37)
        text(5, 98, "対象: " + s.party[self.info_character].name, 2, 37)
        self.footer("左右:人 上下:項目 Z:実行 X:戻る")

    def draw_boss_message(self):
        boss = self.dungeon.boss_data
        self.title(f"B{self.dungeon.floor + 1}F / {boss['name']}")
        pyxel.rectb(3, 17, 154, 84, 2)
        for i, line in enumerate(self.message_lines[self.message_page * 8:(self.message_page + 1) * 8]):
            text(7, 24 + i * 9, line, 3, 36)
        more = (self.message_page + 1) * 8 < len(self.message_lines)
        self.footer("A:続きを読む" if more else "A:戦闘開始 B:戻る" if self.state == "boss_message" else "A:先へ進む")

    def update_guardians(self):
        confirm, cancel = self.confirm(), self.cancel()
        if self.state == 'guardian_warning' and cancel:
            self.state = 'explore'
            return
        if not confirm:
            return
        if (self.message_page + 1) * 8 < len(self.message_lines):
            self.message_page += 1
            return
        f = self.dungeon.finale
        if self.state == 'guardian_warning':
            f.start_guardians()
            self.next_guardian_index = 0
            self.begin_encounter(boss=True, guardian_index=0)
        elif self.state == 'guardian_between':
            self.begin_encounter(boss=True, guardian_index=f.guardian_index)
        else:
            self.next_guardian_index = None
            self.state = 'explore'

    def draw_guardians(self):
        self.title('B15F / 守護者')
        pyxel.rectb(3, 17, 154, 84, 2)
        for i, line in enumerate(self.message_lines[self.message_page * 8:(self.message_page + 1) * 8]):
            text(7, 24 + i * 9, line, 3, 36)
        more = (self.message_page + 1) * 8 < len(self.message_lines)
        label = ('A:連戦へ B:戻る' if self.state == 'guardian_warning' else
                 'A:次の戦い' if self.state == 'guardian_between' else 'A:泉の先へ')
        self.footer('A:続きを読む' if more else label)

    def show_amrita_offer(self):
        self.state, self.overlay, self.notice_timer = 'amrita_offer', None, 0
        self.final_choice = 0
        self.final_question_page = 0
        self.camp_offer_pending = False

    def start_final_story(self):
        self.dungeon.finale.start_final_event()
        self.state, self.overlay = 'final_story', None
        self.final_story_page = 0
        self.sync_scene_audio()

    def begin_final_battle(self):
        self.final_presentation = None
        f = self.dungeon.finale
        if not f.final_event_started or not f.has_amrita or f.amrita_power_spent:
            raise ValueError('アムリタを持って最終イベントへ進んでください。')
        if self.final_checkpoint is None:
            self.final_checkpoint = FinalBattleCheckpoint.capture(self.session, self.dungeon, self.exploration)
        self.battle = self.session.next_battle([make_final_enemy(self.session.enemy_data)],
            recover=False, boss=True, final_progress=f, final_data=self.final_battle_data)
        self.battle_kind, self.battle_is_boss = 'elysion', True
        self.battle_position = None
        self.overlay, self.notice_timer, self.shake_timer = None, 0, 0
        self.debug_return_state, self.debug_return_overlay = None, 'debug_skills'
        self.fanfare_started_at = self.fanfare_start_frame = None
        self.fanfare_timed_out = False
        self.log = wrap_lines(self.final_battle_data['battle_start'], 37)[-3:]
        self.pending = deque()
        self.begin_input()
        self.battle_input_blocked = True
        self.audio.play_bgm('bgm_boss')

    def update_final_event(self):
        if self.pressed(pyxel.KEY_Q):
            pyxel.quit()
            return
        if self.pressed(pyxel.KEY_F9):
            self.session.debug = not self.session.debug
            return
        confirm, cancel = self.confirm(), self.cancel()
        if self.state in ('amrita_offer', 'final_retry'):
            page = getattr(self, 'final_question_page', 0)
            if page + 1 < len(self.final_question_pages()) and not cancel:
                if confirm:
                    self.final_question_page = page + 1
                return
            self.final_choice = (self.final_choice + self.direction()) % 2
            if cancel:
                self.final_choice = 1
                confirm = True
            if not confirm:
                return
            if self.state == 'amrita_offer':
                if self.final_choice:
                    self.state = 'camp'
                else:
                    self.start_final_story()
            elif self.final_choice:
                stop_battle_music()
                self.state, self.title_cursor = 'title', 0
                self.audio.play_bgm('bgm_title')
                self.opening_input_blocked = True
            else:
                if self.final_checkpoint is None:
                    raise ValueError('決戦前の記録がありません。')
                stop_battle_music()
                self.final_checkpoint.restore(self.session, self.dungeon, self.exploration)
                self.begin_final_battle()
        elif self.state == 'final_story' and confirm:
            pages = self.final_story_pages()
            if self.final_story_page + 1 < len(pages):
                self.final_story_page += 1
            else:
                self.begin_final_battle()
        elif self.state == 'ending' and confirm:
            pages = self.final_ending_pages()
            if self.ending_page + 1 < len(pages):
                self.ending_page += 1
            else:
                self.start_credits()

    def final_story_pages(self):
        pages = []
        for block in self.final_battle_data['story_pages']:
            lines = wrap_lines(block, 36)
            pages.extend(lines[i:i + 8] for i in range(0, len(lines), 8))
        return pages

    def final_question_pages(self):
        key = 'offer_question' if self.state == 'amrita_offer' else 'retry_question'
        lines = wrap_lines(self.final_battle_data[key], 36)
        return [lines[i:i + 5] for i in range(0, len(lines), 5)]

    def final_ending_pages(self):
        lines = wrap_lines(self.final_battle_data['victory'] + [''] + self.final_battle_data['ending_lines'], 36)
        return [lines[i:i + 8] for i in range(0, len(lines), 8)]

    def draw_final_event(self):
        pyxel.cls(0)
        if self.state in ('amrita_offer', 'final_retry'):
            self.title('王への献上' if self.state == 'amrita_offer' else '決戦 / 再挑戦')
            pages = self.final_question_pages()
            page = getattr(self, 'final_question_page', 0)
            for i, line in enumerate(pages[page]):
                text((pyxel.width - text_width(line)) // 2, 24 + i * 9, line, 3)
            if page + 1 < len(pages):
                self.footer('A:続きを読む B:戻る')
                return
            options = ('はい', '後で' if self.state == 'amrita_offer' else 'いいえ')
            for i, label in enumerate(options):
                display = ('> ' if self.final_choice == i else '  ') + label
                text((pyxel.width - text_width(display)) // 2, 78 + i * 14,
                     display, 3 if self.final_choice == i else 2)
            self.footer('上下:選択 A:決定 B:タイトルへ' if self.state == 'final_retry' else
                        '上下:選択 A:決定 B:戻る')
        else:
            ending = self.state == 'ending'
            self.title('旅の結末' if ending else '王城')
            pages = self.final_ending_pages() if ending else self.final_story_pages()
            current = self.ending_page if ending else self.final_story_page
            for i, line in enumerate(pages[current]):
                text(7, 24 + i * 9, line, 3, 36)
            last = current + 1 == len(pages)
            self.footer('A:スタッフロールへ' if ending and last else 'A:決戦へ' if last else 'A:続きを読む')

    def debug_final_stage(self, stage):
        if not self.session.debug or stage not in ('key', 'offer', 'story', 'battle'):
            return False
        if self.session.pending_replacements:
            self.tell('先に技の入替を終えてください。')
            return False
        f = self.dungeon.finale
        f.abort_guardians()
        f.guardians_defeated = f.demon_defeated = f.has_amrita = True
        f.final_event_started = f.lord_of_elysion_defeated = f.amrita_power_spent = False
        self.dungeon.defeated_bosses.add(14)
        self.final_checkpoint = None
        if stage == 'key':
            self.tell('DEBUG: アムリタ所持ON')
        else:
            self.enter_camp()
            if stage == 'offer':
                self.show_amrita_offer()
            else:
                self.start_final_story()
                if stage == 'battle':
                    self.begin_final_battle()
        return True

    def update_dungeon_debug(self):
        for key, stage in ((pyxel.KEY_4, 'key'), (pyxel.KEY_5, 'offer'),
                           (pyxel.KEY_6, 'story'), (pyxel.KEY_7, 'battle')):
            if self.pressed(key):
                self.debug_final_stage(stage)
                return
        self.floor_cursor = (self.floor_cursor + self.direction()) % 15
        for key, floor in zip((pyxel.KEY_1, pyxel.KEY_2, pyxel.KEY_3), BOSS_FLOORS):
            if self.pressed(key):
                self.dungeon.defeated_bosses.symmetric_difference_update({floor})
                if floor == 14:
                    defeated = floor in self.dungeon.defeated_bosses
                    f = self.dungeon.finale
                    f.abort_guardians()
                    f.guardians_defeated = f.demon_defeated = f.has_amrita = defeated
        if self.pressed(pyxel.KEY_G, pyxel.KEY_M):
            demon = self.pressed(pyxel.KEY_M)
            self.dungeon.debug_floor(14)
            f = self.dungeon.finale
            f.abort_guardians()
            if demon:
                f.guardians_defeated = True
            self.dungeon.x, self.dungeon.y = self.dungeon.find(14, TILE_BOSS if demon else TILE_WARNING)
            self.state, self.overlay, self.notice_timer = 'explore', None, 0
            return
        if self.pressed(pyxel.KEY_Z, pyxel.KEY_RETURN, pyxel.KEY_B):
            boss = self.pressed(pyxel.KEY_B)
            floor = BOSS_FLOORS[self.floor_cursor // 5] if boss else self.floor_cursor
            self.dungeon.debug_floor(floor)
            if boss:
                self.dungeon.x, self.dungeon.y = self.dungeon.find(floor, TILE_BOSS)
                if floor == 14:
                    self.dungeon.finale.guardians_defeated = True
            self.state, self.overlay, self.notice_timer = "explore", None, 0
        elif self.pressed(pyxel.KEY_X, pyxel.KEY_ESCAPE):
            self.overlay = None
            if self.state == "clear" and not self.dungeon.cleared:
                self.state = "explore"

    def draw_dungeon_debug(self):
        d = self.dungeon
        multiplier = d.settings['spark_multipliers'][self.floor_cursor]
        rate = spark_probability(self.session.settings, multiplier)
        debug_rate = spark_probability(self.session.settings, multiplier, True)
        self.title("DEBUG / 階層とボス")
        text(5, 17, f"移動先 B{self.floor_cursor + 1}F / エリア{self.floor_cursor // 5 + 1}", 3, 37)
        text(5, 29, f"閃き x{multiplier:.2f} 通常{rate:.1%}", 2, 37)
        text(5, 39, f"DEBUG中 {debug_rate:.1%} / 1人ごと", 2, 37)
        for i, floor in enumerate(BOSS_FLOORS):
            flag = "ON 撃破済" if floor in d.defeated_bosses else "OFF 未撃破"
            text(5, 51 + i * 10, f"{i + 1}: B{floor + 1}F {flag}", 3, 37)
        text(5, 82, 'G:守護者前 M:デーモン前', 2, 37)
        text(5, 92, '4:秘宝 5:献上 6:会話 7:決戦', 2, 37)
        text(5, 102, '上下:階 B:ボス前', 2, 37)
        self.footer("Z:移動 1/2/3:撃破切替 X:閉じる")

    def draw_effects(self):
        units = self.battle.enemies + self.session.party
        unit = units[self.effect_cursor % len(units)]
        multiplier = self.session.spark_multiplier
        rate = spark_probability(self.session.settings, multiplier, self.session.debug)
        self.title("DEBUG AUDIO: " + self.audio_state())
        text(5, 16, f"{unit.name} 閃き x{multiplier:.2f} = {rate:.1%}", 2, 37)
        text(5, 27, f"AGI {battle_agility(unit):g} DEF {getattr(unit, 'defense', 0) * effect_factor(unit, 'armor_break'):g} GUARD {'ON' if unit.guarding else 'OFF'}", 2, 37)
        if not self.battle.boss:
            text(5, 98, f"RUN {self.battle.run_chance():.0%} F6成功/F8失敗", 2, 37)
        for i, (effect, (factor, turns)) in enumerate(list(unit.effects.items())[:3]):
            text(5, 40 + i * 10, f"{EFFECTS[effect]} x{factor:g} 残{turns}T", 3, 37)
        if not unit.effects:
            text(5, 44, "補助効果なし", 2, 37)
        if unit in self.session.party:
            uses = unit.category_uses
            text(5, 73, "物/速/魔/補/癒 " + "/".join(str(uses.get(k, 0)) for k in
                 ("physical", "speed", "magic", "support", "healing")), 2, 37)
            text(5, 85, "補正 " + " ".join(f"{s}+{growth_bonus(unit, s, self.session.settings):.0%}"
                 for s in ("HP", "STR", "AGI", "INT")), 2, 37)
        self.footer("上下:敵/味方 F3/X:閉じる")

    def draw_help(self):
        pyxel.cls(0)
        self.title("ヘルプ / 操作")
        lines = ["D-PAD  移動・選択", "A  決定・調べる・会話送り", "B  キャンセル・戻る", "探索中のB  メニュー", "PC: A=Zキー B=Xキー",
                 "戦闘 SKILL/ITEM/GUARD/RUN", "GUARD:今ターンの被害半減", "技を使い切るとMASTERED",
                 self.session.skills['return'].name + ":有限Usesの帰還スキル", "探索メニュー/技一覧から使用"]
        for i, line in enumerate(lines):
            text(5, 16 + i * 9, line, 3 if i < 5 else 2, 37)
        self.footer("B:閉じる")
