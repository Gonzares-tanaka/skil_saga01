"""160x120 UI. All rules live outside this module."""
from collections import deque
import time
from .statuses import active_statuses, clear_statuses
from .skill_targets import AUTO_TARGETS

import pyxel

from .art import load_art
from .models import Action
from .labels import TYPES, RARITIES, TARGETS, OUTCOMES, EFFECTS, CURRENCY_NAME
from .text import text, wrap_lines, font, DescriptionScroll
from .runtime import development_enabled
from .sound import init_sound, play_cue, start_battle_music, stop_battle_music, play_victory_music, music_is_playing
from .growth import growth_bonus
from .keyboard import GameKeyboard
from .opening import GAME_TITLE
from .final_battle import AMRITA_ITEM_ID, LORD_OF_ELYSION_ID
from .final_presentation import FinalPresentation, AMRITA_MESSAGE_FRAME
from .battle_presentation import (BattlePresentation, result_pages, draw_status_icons, draw_battle_background,
                                  enemy_position, ASSET_BANK, KO_SPRITE_U, KO_SPRITE_V,
                                  KO_SPRITE_W, KO_SPRITE_H)


# The official Web touch pad emits gamepad buttons, not keyboard keys.
GAMEPAD_KEYS = {
    pyxel.KEY_UP: pyxel.GAMEPAD1_BUTTON_DPAD_UP,
    pyxel.KEY_DOWN: pyxel.GAMEPAD1_BUTTON_DPAD_DOWN,
    pyxel.KEY_LEFT: pyxel.GAMEPAD1_BUTTON_DPAD_LEFT,
    pyxel.KEY_RIGHT: pyxel.GAMEPAD1_BUTTON_DPAD_RIGHT,
    pyxel.KEY_Z: pyxel.GAMEPAD1_BUTTON_A,
    pyxel.KEY_X: pyxel.GAMEPAD1_BUTTON_B,
}

FANFARE_MAX_WAIT_SECONDS = 4.5
FANFARE_MAX_WAIT_FRAMES = 150
FANFARE_PRESENTATION_SECONDS = 2.4  # Existing score duration; no channel polling.
FANFARE_PRESENTATION_FRAMES = 72
QUIT_SELECT_HOLD_SECONDS = 1.0


class App:
    def __init__(self, session, run=True, headless=False, battle_on_start=True):
        self.session = session
        self.debug_allowed = development_enabled(session.debug)
        self.session.debug = self.debug_allowed
        pyxel.init(160, 120, title=GAME_TITLE, fps=30,
                   display_scale=5, quit_key=pyxel.KEY_NONE, headless=headless)
        self.keyboard = GameKeyboard(enabled=not headless)
        self.quit_select_started_at = None
        self.keyboard.update()
        load_art(pyxel)
        font()
        self.audio = init_sound()
        self.overlay = None
        self.info_character = self.info_tab = self.scroll = 0
        self.result_page = 0
        self.notice = ""
        self.notice_timer = 0
        self.replacement_cursor = 0
        self.replacement_confirm = False
        self.debug_return_state = None
        self.debug_return_overlay = "debug_skills"
        self.debug_cursor = 0
        self.shake_timer = 0
        self.fanfare_started_at = None
        self.fanfare_start_frame = None
        self.fanfare_timed_out = False
        self.debug_events = []
        self.final_presentation = None
        self.battle_presentation = None
        if battle_on_start:
            self.start_battle()
        if run:
            pyxel.run(self.update, self.draw)

    def start_battle(self):
        self.final_presentation = None
        self.notice_timer = 0
        self.fanfare_started_at = None
        self.fanfare_start_frame = None
        self.battle = self.session.next_battle()
        self.log = ["新たな敵が現れた", "4人の行動を選ぼう"]
        self.pending = deque()
        self.begin_input()
        start_battle_music()

    def finish_results(self):
        if self.waiting_for_fanfare():
            return
        stop_battle_music()
        self.trace("NEXT BATTLE")
        self.start_battle()

    def waiting_for_fanfare(self):
        if self.battle.outcome != "VICTORY" or self.fanfare_started_at is None:
            return False
        elapsed = time.monotonic() - self.fanfare_started_at
        frames = pyxel.frame_count - self.fanfare_start_frame
        ticks = getattr(self, 'fanfare_visual_frames', 0)
        if (elapsed >= FANFARE_PRESENTATION_SECONDS or frames >= FANFARE_PRESENTATION_FRAMES or
            ticks >= FANFARE_PRESENTATION_FRAMES):
            if not self.fanfare_timed_out:
                self.fanfare_timed_out = elapsed >= FANFARE_MAX_WAIT_SECONDS or frames >= FANFARE_MAX_WAIT_FRAMES
                self.trace("VICTORY PRESENTATION END")
                stop_battle_music()
            self.fanfare_started_at = None
            return False
        return True

    def trace(self, event):
        if self.session.debug:
            message = f"[SPARK] {event} state={self.state} battle={self.session.completed}"
            self.debug_events.append(message)
            self.debug_events = self.debug_events[-40:]
            print(message)

    def audio_state(self):
        try:
            import js
            return str(js.window.sparkAudioState()).upper()
        except Exception:
            return "N/A"

    def next_result_label(self):
        return "次の戦闘"

    def begin_input(self):
        self.state = "command"
        self.actions = []
        self.order = [i for i, c in enumerate(self.session.party) if c.alive]
        self.actor_position = 0
        self.cursor = self.skill_cursor = self.target_cursor = 0
        self.selected_skill = None
        self.selected_item = None
        self.item_cursor = 0
        self.skip_confused_commands()
        if self.actor_position >= len(self.order) and self.order:
            self.battle.begin_round(self.actions)
            self.state, self.delay = 'resolve', 0
            self.log = [f'第{self.battle.round}ターン']

    def skip_confused_commands(self):
        while self.actor_position < len(self.order):
            index = self.order[self.actor_position]
            if 'confusion' not in active_statuses(self.session.party[index]):
                break
            self.actions.append(Action(index, 'STATUS'))
            self.actor_position += 1

    @property
    def actor_index(self):
        return self.order[min(self.actor_position, len(self.order) - 1)]

    @property
    def actor(self):
        return self.session.party[self.actor_index]

    def pressed(self, *keys):
        return any(self.button_pressed(key) for key in keys)

    def confirm(self):
        return self.pressed(pyxel.KEY_Z, pyxel.KEY_RETURN, pyxel.KEY_SPACE)

    def cancel(self):
        return self.pressed(pyxel.KEY_X, pyxel.KEY_ESCAPE)

    def confirm_held(self):
        return pyxel.btn(pyxel.KEY_Z) or pyxel.btn(pyxel.GAMEPAD1_BUTTON_A)

    def button_pressed(self, key, hold=0, repeat=0):
        return pyxel.btnp(key, hold, repeat) or (
            key in GAMEPAD_KEYS and pyxel.btnp(GAMEPAD_KEYS[key], hold, repeat))

    def direction(self, horizontal=False):
        low, high = (pyxel.KEY_LEFT, pyxel.KEY_RIGHT) if horizontal else (pyxel.KEY_UP, pyxel.KEY_DOWN)
        return int(self.button_pressed(high, 10, 3)) - int(self.button_pressed(low, 10, 3))

    def handle_quit_input(self):
        """Exit without saving; leave plumOS SELECT + D-pad shortcuts usable."""
        if getattr(self, 'debug_allowed', False) and self.pressed(pyxel.KEY_Q):
            pyxel.quit()
            return True
        dpad = (pyxel.GAMEPAD1_BUTTON_DPAD_UP, pyxel.GAMEPAD1_BUTTON_DPAD_DOWN,
                pyxel.GAMEPAD1_BUTTON_DPAD_LEFT, pyxel.GAMEPAD1_BUTTON_DPAD_RIGHT)
        if pyxel.btn(pyxel.GAMEPAD1_BUTTON_BACK) and not any(pyxel.btn(key) for key in dpad):
            now = time.monotonic()
            started = getattr(self, "quit_select_started_at", None)
            if started is None:
                self.quit_select_started_at = now
            elif now - started >= QUIT_SELECT_HOLD_SECONDS:
                pyxel.quit()
                return True
        else:
            self.quit_select_started_at = None
        return False

    def tell(self, message):
        self.notice, self.notice_timer = message, 60

    def targets(self):
        if self.selected_item or (self.selected_skill and self.selected_skill.target == "ally"):
            dead = self.selected_item == "PHOENIX ASH" or (self.selected_skill and self.selected_skill.effect == "revive")
            return [(i, target) for i, target in enumerate(self.session.party)
                    if target.alive != bool(dead) and
                    (self.selected_item != "POTION" or target.hp < target.max_hp) and
                    (self.selected_item != 'REMEDY' or active_statuses(target))]
        return [(i, target) for i, target in enumerate(self.battle.enemies) if target.alive]

    def battle_items(self):
        reserved = {item: sum(a.kind == "ITEM" and a.item_id == item for a in self.actions)
                    for item in ("POTION", "PHOENIX ASH", "REMEDY")}
        options = [item for item in reserved if self.session.inventory.counts[item] > reserved[item]
                   and (item != 'REMEDY' or any(c.alive and active_statuses(c) for c in self.session.party))]
        if self.battle.can_use_amrita and not any(a.item_id == AMRITA_ITEM_ID for a in self.actions):
            options.append(AMRITA_ITEM_ID)
        return options

    def commit(self, action):
        if action.kind == 'SKILL':
            self.session.party[action.actor].remember_skill(action.skill_id)
        self.actions.append(action)
        self.actor_position += 1
        self.skip_confused_commands()
        self.cursor = self.skill_cursor = self.target_cursor = 0
        self.selected_skill = None
        self.selected_item = None
        if self.actor_position >= len(self.order):
            self.battle.begin_round(self.actions)
            self.state, self.delay = "resolve", 0
            self.log = [f"第{self.battle.round}ターン"]
        else:
            self.state = "command"

    def update_status_debug(self, confirm, cancel):
        units = self.session.party + self.battle.enemies
        self.status_debug_target = (self.status_debug_target + self.direction()) % len(units)
        self.status_debug_cursor = (self.status_debug_cursor + self.direction(horizontal=True)) % 5
        if cancel:
            self.overlay = None
            self.begin_input()
        elif confirm:
            from .statuses import STATUS_IDS
            target = units[self.status_debug_target]
            if self.status_debug_cursor == 4:
                clear_statuses(target)
                self.tell('DEBUG: 状態異常を解除')
            else:
                ident = STATUS_IDS[self.status_debug_cursor]
                applied = self.battle.apply_status(target, ident)
                self.tell('DEBUG: 付与' if applied else 'DEBUG: 付与失敗（KO/制御状態/耐性）')

    def draw_status_debug(self):
        from .statuses import STATUS_IDS
        units = self.session.party + self.battle.enemies
        unit = units[self.status_debug_target]
        self.title('DEBUG / 状態異常')
        text(5, 17, unit.name, 3, 36)
        names = [self.battle.status_definitions[k].name for k in STATUS_IDS] + ['解除']
        text(5, 32, ' / '.join(names), 2, 36)
        text(5, 44, '> ' + names[self.status_debug_cursor], 3, 36)
        for i, (ident, turns) in enumerate(active_statuses(unit).items()):
            text(5, 61 + i * 12, f'{self.battle.status_definitions[ident].name} 残{turns}T', 3, 36)
        self.footer('上下:対象 左右:種類 A:付与 B:戻る')

    def update(self):
        if not getattr(self, 'debug_allowed', False):
            self.session.debug = False
        self.keyboard.update()
        if self.handle_quit_input():
            return
        if self.update_rescue_notice():
            return
        if self.state == 'amrita_effect':
            self.update_amrita_effect()
            return
        if self.state == 'resolve' and self.battle_visual().active:
            self.update_battle_visual()
            return
        self.shake_timer = max(0, self.shake_timer - 1)
        self.notice_timer = max(0, self.notice_timer - 1)
        if getattr(self, 'debug_allowed', False) and self.pressed(pyxel.KEY_F9):
            self.session.debug = not self.session.debug
            self.tell("DEBUG オン" if self.session.debug else "DEBUG オフ")
            if not self.session.debug and self.overlay == "debug_skills":
                self.overlay = None
            return
        if self.pressed(pyxel.KEY_F12):
            if self.session.debug and self.state in ("camp", "explore", "result") and not self.session.pending_replacements:
                self.overlay = None if self.overlay == "debug_skills" else "debug_skills"
                self.notice_timer = 0
            return
        inspectable = (self.state in ('camp', 'explore', 'menu', 'command', 'skill')
                       and self.overlay in (None, 'info', 'help')
                       and not self.session.pending_replacements
                       and self.session.pending_relearn is None)
        if inspectable and self.pressed(pyxel.KEY_D, pyxel.KEY_TAB):
            self.overlay = None if self.overlay == "info" else "info"
            self.scroll = 0
            return
        if inspectable and self.pressed(pyxel.KEY_H):
            self.overlay = None if self.overlay == "help" else "help"
            return
        confirm, cancel = self.confirm(), self.cancel()
        if self.overlay == 'status_debug':
            self.update_status_debug(confirm, cancel)
            return
        if self.session.debug and self.state == 'command' and self.pressed(pyxel.KEY_F2):
            self.overlay = 'status_debug'
            self.status_debug_target = self.status_debug_cursor = 0
            return
        if self.overlay:
            if cancel:
                self.overlay = None
            elif self.overlay == "debug_skills":
                self.update_debug_skills(confirm)
            elif self.overlay == "info":
                move = self.direction(horizontal=True)
                if move:
                    self.info_tab = (self.info_tab + move) % 3
                    self.scroll = 0
                elif self.info_tab == 0:
                    self.info_character = (self.info_character + self.direction()) % 4
                else:
                    self.scroll = max(0, min(self.info_scroll_limit(), self.scroll + self.direction()))
            return
        if self.state == "replace":
            self.update_replacement(confirm, cancel)
            return
        if self.state == "result":
            self.fanfare_visual_frames = getattr(self, 'fanfare_visual_frames', 0) + 1
            page_count = max(1, (len(self.result_lines) + 8) // 9)
            self.result_page = max(0, min(page_count - 1, self.result_page + self.direction(horizontal=True) + self.direction()))
            if confirm:
                if self.result_page + 1 < page_count:
                    self.result_page += 1
                else:
                    if self.waiting_for_fanfare():
                        return
                    if self.session.pending_replacements:
                        self.notice_timer = 0
                        self.state = "replace"
                        self.trace("REPLACEMENT")
                        self.replacement_cursor = 0
                        self.replacement_confirm = False
                    else:
                        self.finish_results()
            return
        if self.state == "resolve":
            self.delay -= 1
            if self.delay > 0 and not confirm and not self.confirm_held():
                return
            if self.pending:
                self.log.append(self.pending.popleft())
                self.log = self.log[-3:]
                self.delay = 14
            elif self.battle.outcome:
                self.trace("VICTORY START" if self.battle.outcome == "VICTORY" else "BATTLE END")
                stop_battle_music()
                self.notice_timer = 0
                self.set_result_pages(self.session.settle())
                self.trace("REWARD GROWTH MASTERY SPARK COMPLETE")
                self.result_page = 0
                self.state = "result"
                self.trace("RESULT")
                if self.battle.outcome == "VICTORY":
                    if play_victory_music():
                        self.fanfare_started_at = time.monotonic()
                        self.fanfare_start_frame = pyxel.frame_count
                        self.fanfare_timed_out = False
                        self.fanfare_visual_frames = 0
                        self.trace("FANFARE START")
                    else:
                        self.fanfare_started_at = None
                        self.trace("FANFARE UNAVAILABLE")
            elif self.battle.queue:
                visual = self.battle_visual()
                if visual.start():
                    action = self.battle.queue[0][1]
                    name = self.battle.skills[action.skill_id].name if action.kind == 'SKILL' else action.item_id
                    if action.kind == 'ITEM' and action.item_id != AMRITA_ITEM_ID:
                        name = self.session.inventory.label(action.item_id)
                    self.log = (self.log + [self.session.party[action.actor].name + ' ' + name])[-3:]
                else:
                    self.apply_visual_action()
            else:
                self.begin_input()
            return
        if self.state == "command":
            if self.session.debug and getattr(self, 'debug_allowed', False) and self.pressed(pyxel.KEY_A):
                self.battle.begin_round(self.battle.auto_actions())
                self.state, self.delay = "resolve", 0
                self.log = [f"第{self.battle.round}ターン / 自動"]
                return
            vertical, horizontal = self.direction(), self.direction(horizontal=True)
            self.cursor = (((self.cursor // 2 + vertical) % 2) * 2
                           + (self.cursor % 2 + horizontal) % 2)
            if cancel and self.actions:
                self.actions.pop()
                self.actor_position -= 1
                self.cursor = 0
            elif confirm:
                if self.cursor == 0:
                    if self.actor.skills:
                        self.state, self.skill_cursor = "skill", self.actor.remembered_skill_index()
                    else:
                        self.tell("使える技がありません")
                elif self.cursor == 1:
                    self.state, self.item_cursor = "battle_item", 0
                elif self.cursor == 2:
                    self.commit(Action(self.actor_index, "GUARD"))
                else:
                    lines = self.battle.attempt_run()
                    if self.battle.boss:
                        self.tell(lines[0])
                    else:
                        self.actions.clear()
                        self.pending = deque(lines)
                        self.state, self.delay = "resolve", 0
                        if self.battle.outcome == 'ESCAPE':
                            self.log = lines
                            self.pending.clear()
                            stop_battle_music()
                            self.battle_visual().start_run()
                            play_cue('run_success')
        elif self.state == "battle_item":
            options = self.battle_items()
            if cancel:
                self.state = "command"
                self.selected_item = None
            elif options:
                self.item_cursor = (self.item_cursor + self.direction()) % len(options)
                if confirm:
                    self.selected_item = options[self.item_cursor]
                    if self.selected_item == AMRITA_ITEM_ID:
                        self.commit(Action(self.actor_index, 'ITEM', item_id=AMRITA_ITEM_ID))
                    elif not self.targets():
                        self.tell("使える対象がいません")
                    else:
                        self.state, self.target_cursor = "target", 0
            elif confirm:
                self.tell("使える道具がありません")
        elif self.state == "skill":
            if not self.actor.skills:
                self.state = "command"
                self.tell("使える技がありません")
                return
            self.skill_cursor = (self.skill_cursor + self.direction()) % len(self.actor.skills)
            if cancel:
                self.state = "command"
                self.selected_skill = None
            elif confirm:
                skill = self.session.skills[self.actor.skills[self.skill_cursor]]
                if self.actor.skill_uses.get(skill.id, 0) <= 0:
                    self.tell("残り回数がありません")
                elif skill.effect == "return":
                    self.tell(skill.name + "は探索メニューから使用")
                elif self.actor.cooldowns.get(skill.id, 0):
                    self.tell("この技は再使用待ちです")
                elif skill.target == "self":
                    self.commit(Action(self.actor_index, "SKILL", self.actor_index, skill.id))
                elif skill.target in AUTO_TARGETS:
                    self.commit(Action(self.actor_index, "SKILL", 0, skill.id))
                else:
                    self.selected_skill = skill
                    if not self.targets():
                        self.selected_skill = None
                        self.tell("使える対象がいません")
                    else:
                        self.state, self.target_cursor = "target", 0
        elif self.state == "target":
            choices = self.targets()
            if not choices:
                self.state = "battle_item" if self.selected_item else "skill"
                return
            self.target_cursor = (self.target_cursor + self.direction() + self.direction(horizontal=True)) % len(choices)
            if cancel:
                self.state = "battle_item" if self.selected_item else "skill"
                self.selected_item = None
                self.selected_skill = None
            elif confirm:
                target = choices[self.target_cursor][0]
                if self.selected_item:
                    self.commit(Action(self.actor_index, "ITEM", target, item_id=self.selected_item))
                else:
                    self.commit(Action(self.actor_index, "SKILL", target, self.selected_skill.id))

    def panel(self, x, y, w, h):
        pyxel.rect(x, y, w, h, 0)
        pyxel.rectb(x, y, w, h, 2)

    def footer(self, value):
        pyxel.rect(0, 111, 160, 9, 1)
        text(4, 112, self.notice if self.notice_timer else value, 3, 38)

    def title(self, value):
        pyxel.rect(0, 0, 160, 11, 3)
        text(4, 2, value, 0, 38)

    def draw(self):
        if hasattr(self, 'description_scroll'):
            self.description_scroll.begin_frame()
        pyxel.cls(0)
        if self.overlay == 'rescue':
            if getattr(self, 'battle', None):
                self.draw_battle()
            self.draw_rescue_notice()
            return
        if self.overlay == 'status_debug':
            self.draw_status_debug()
        elif self.state == 'amrita_effect':
            try:
                pyxel.camera(*self.final_visual().shake_offset())
                self.draw_battle()
                self.final_visual().draw_light(pyxel)
            except Exception as error:
                # A presentation fault must never hold a resolved ITEM action.
                self.trace('AMRITA VISUAL UNAVAILABLE: ' + type(error).__name__)
                self.finish_amrita_effect()
            finally:
                pyxel.pal()
                pyxel.camera()
        elif self.overlay == "debug_skills":
            self.draw_debug_skills()
        elif self.overlay == "help":
            self.draw_help()
        elif self.overlay == "info":
            self.draw_info()
        elif self.state == "result":
            self.draw_result()
        elif self.state == "replace":
            self.draw_replacement()
        elif self.state == "skill":
            self.draw_skills()
        elif self.state == "battle_item":
            self.draw_battle_items()
        else:
            shake = self.battle_visual().shake_offset()
            if shake != (0, 0):
                pyxel.camera(*shake)
            elif self.shake_timer:
                offsets = ((-2, 0), (2, 1), (-1, -1), (1, 0), (0, 1), (0, 0))
                pyxel.camera(*offsets[6 - self.shake_timer])
            self.draw_battle()
            if self.shake_timer or shake != (0, 0):
                pyxel.camera()

    def draw_battle(self):
        flag = " DEBUG" if self.session.debug else ""
        self.title(f"第{self.session.completed + 1}戦 {self.battle.round + (self.state not in ('resolve', 'amrita_effect'))}ターン{flag}")
        visual = self.battle_visual()
        area = None if self.battle.is_elysion_battle else getattr(self, 'battle_background_area', None)
        if area is None:
            pyxel.rect(0, 67, 96, 13, 0)
            for x in range(5, 91, 8):
                pyxel.pset(x, 75, 1)
        else:
            draw_battle_background(pyxel, area)
        for i, enemy in enumerate(self.battle.enemies):
            x, y = enemy_position(i, len(self.battle.enemies))
            x += visual.enemy_offset(i)
            visible, sink = visual.enemy_visual(i)
            if visible:
                if self.battle.is_elysion_battle and enemy.id == LORD_OF_ELYSION_ID:
                    flashing = visual.target_flashing('enemy', i)
                    if flashing:
                        pyxel.pal(1, 3); pyxel.pal(2, 3)
                    self.draw_lord_of_elysion(enemy)
                    if flashing:
                        pyxel.pal()
                elif enemy.id == 'ancient_dragon':
                    from .postgame import draw_dragon
                    pyxel.clip(0,11,96,53)
                    flashing = visual.target_flashing('enemy', i)
                    if flashing:
                        pyxel.pal(1, 3); pyxel.pal(2, 3)
                    draw_dragon(pyxel,x,y,sink=sink)
                    if flashing:
                        pyxel.pal()
                    pyxel.clip()
                else:
                    pyxel.clip(0, 11, 96, y + 16 - 11)
                    flashing = visual.target_flashing('enemy', i)
                    if flashing:
                        pyxel.pal(1, 3); pyxel.pal(2, 3)
                    pyxel.blt(x, y + sink, 0, *enemy.sprite, 16, 16, 0)
                    if flashing:
                        pyxel.pal()
                    pyxel.clip()
                if enemy.alive:
                    icon_x, icon_y = x - 9, y
                    if self.battle.is_elysion_battle:
                        fx, fy, _, _ = self.final_visual().bounds()
                        icon_x, icon_y = fx - 9, fy
                    elif enemy.id == 'ancient_dragon':
                        from .postgame import dragon_bounds
                        fx, fy, _, _ = dragon_bounds(x,y)
                        icon_x, icon_y = fx - 9, fy
                    draw_status_icons(pyxel, enemy, max(0, icon_x), icon_y, limit=2,
                                      vertical=True, definitions=self.battle.status_definitions)
        for i, actor in enumerate(self.session.party):
            y = 13 + i * 16
            active = (self.state in ("command", "target", "battle_transition") and self.actor_index == i
                      or visual.active and visual.actor == i)
            pyxel.rect(97, y, 62, 16, 1 if active else 0)
            offset = visual.actor_offset(i)
            running = visual.phase == 'run_success'
            recoiling = visual.party_recoiling(i)
            showing_hit = visual.holds_party_sprite(i)
            if actor.alive or showing_hit:
                flashing = visual.target_flashing('party', i)
                if flashing:
                    pyxel.pal(1, 3); pyxel.pal(2, 3)
                pyxel.blt(98 + offset, y, 0, *actor.sprite, -16 if running else 16, 16, 0)
                if flashing:
                    pyxel.pal()
                if not running and actor.alive:
                    draw_status_icons(pyxel, actor, 82 + offset,
                                      y + 3, limit=2,
                                      definitions=self.battle.status_definitions)
            else:
                pyxel.blt(98 + offset, y, ASSET_BANK, KO_SPRITE_U, KO_SPRITE_V,
                          -KO_SPRITE_W if running else KO_SPRITE_W, KO_SPRITE_H, 0)
            if running:
                continue  # Leave room for the four moving sprites, without text overlap.
            label_x = 119 if recoiling else 115
            shown_hp = visual.displayed_hp(i)
            text(label_x, y + 1, actor.name, 3 if shown_hp > 0 else 1, 6 if recoiling else 7)
            status = "KO" if shown_hp <= 0 else "!" if actor.berserk else "+" if actor.guarding else ""
            text(148, y + 1, status, 3, 2)
            text(label_x, y + 8, f"{shown_hp}/{actor.max_hp}", 2, 11)
        visual.draw_effect(pyxel)
        self.panel(1, 80, 158, 31)
        if self.state in ("command", "battle_transition"):
            for i, label in enumerate(("SKILL 技", "ITEM 道具", "GUARD まもる", "RUN 逃走")):
                text(5 + i % 2 * 75, 84 + i // 2 * 12,
                     (">" if i == self.cursor else " ") + label,
                     3 if i == self.cursor else 2)
            self.footer("A:決定 B:戻る D-PAD:選択")
        elif self.state == "target":
            target_index, target = self.targets()[self.target_cursor]
            ally = self.selected_item or (self.selected_skill and self.selected_skill.target == "ally")
            if ally:
                pyxel.rectb(97, 13 + target_index * 16, 62, 16, 3)
            else:
                if self.battle.is_elysion_battle:
                    x, y, _, h = self.final_visual().bounds()
                    text(x - 8, y + h // 2 - 4, ">", 3)
                else:
                    x, y = enemy_position(target_index, len(self.battle.enemies))
                    text(x - 8, y + 4, ">", 3)
            label = self.selected_item or f"{self.selected_skill.name} 残{self.actor.skill_uses[self.selected_skill.id]}"
            if self.selected_item:
                label = self.session.inventory.label(self.selected_item)
            text(5, 84, label, 2, 37)
            target_line = f"> {target.name} HP {target.hp}/{target.max_hp}" if ally else f"> {target.name}"
            text(5, 92, target_line, 3, 37)
            hint = self.cure_target_hint(self.selected_skill, [target]) if not self.selected_item else ""
            text(5, 100, hint + " / 予約可" if hint else "対象を選んでください", 2, 37)
            self.footer("D-PAD:対象 A:決定 B:戻る")
        else:
            for i, line in enumerate(self.log[-3:]):
                text(5, 84 + i * 8, line, 3 if i == len(self.log[-3:]) - 1 else 2, 37)
            self.footer("" if self.state == 'amrita_effect' else "A:メッセージ送り / 長押しで高速")
        visual.legend.draw_name(pyxel, visual.phase)

    def battle_visual(self):
        visual = getattr(self, 'battle_presentation', None)
        if visual is None or visual.battle is not self.battle:
            self.battle_presentation = visual = BattlePresentation(self.battle)
        return visual

    def apply_visual_action(self):
        visual = self.battle_visual()
        before = [enemy.alive for enemy in self.battle.enemies]
        hp_before = [actor.hp for actor in self.session.party]
        barrier_before = self.battle.elysion_barrier_active
        self.pending.extend(wrap_lines(self.battle.step()))
        play_cue(self.battle.sound_cue)
        visual.after_action(before, hp_before)
        if self.battle.player_hit:
            # Strong hits shake at visual impact, for three frames, not during wind-up.
            self.shake_timer = 0 if visual.enemy_action == 'heavy_attack' else 6
        if visual.phase == 'enemy_death':
            play_cue('enemy_defeat')  # Once per death group, never once per blink.
        if barrier_before and not self.battle.elysion_barrier_active:
            visual.reset()
            self.start_amrita_effect()

    def update_battle_visual(self):
        self.shake_timer = max(0, self.shake_timer - 1)
        previous_phase = self.battle_visual().phase
        event = self.battle_visual().advance()
        if previous_phase != 'enemy_death' and self.battle_visual().phase == 'enemy_death':
            play_cue('enemy_defeat')
        if event == 'apply':
            self.apply_visual_action()
        elif event == 'escaped':
            self.session.settle()
            self.pending.clear()
            self.finish_results()

    def set_result_pages(self, lines):
        self.growth_result_pages = result_pages(lines, self.session.party)
        # Retain the existing 9-lines-per-page interface used by result controls.
        self.result_lines = [line for page in self.growth_result_pages
                             for line in page['lines'] + [''] * (9 - len(page['lines']))]

    def final_visual(self):
        if getattr(self, 'final_presentation', None) is None:
            self.final_presentation = FinalPresentation(getattr(self, 'final_battle_data', None))
        return self.final_presentation

    def draw_lord_of_elysion(self, enemy):
        self.final_visual().draw_boss(pyxel, enemy, self.battle.elysion_barrier_active)

    def start_amrita_effect(self):
        # The model has already applied the legal ITEM action and released the barrier.
        # Only presentation pauses here, never sound or the game rule itself.
        self.overlay, self.notice_timer, self.shake_timer = None, 0, 0
        self.pending.clear()
        self.log = wrap_lines(self.battle.final_data['amrita_release'][:1], 37)[-3:]
        try:
            self.final_visual().start()
            self.state = 'amrita_effect'
        except Exception:
            self.finish_amrita_effect()

    def finish_amrita_effect(self):
        if getattr(self, 'final_presentation', None) is not None:
            self.final_presentation.reset()
        self.log = wrap_lines(self.battle.final_data['amrita_release'][1:] or
                              self.battle.final_data['amrita_release'], 37)[-3:]
        self.state, self.delay = 'resolve', 14
        # DungeonApp consumes a released frame before accepting subsequent input.
        self.battle_input_blocked = True

    def update_amrita_effect(self):
        if getattr(self, 'debug_allowed', False) and self.pressed(pyxel.KEY_Q):
            pyxel.quit()
            return
        try:
            visual = self.final_visual()
            finished = visual.advance()
        except Exception:
            self.finish_amrita_effect()
            return
        if finished:
            self.finish_amrita_effect()
        elif visual.frame >= AMRITA_MESSAGE_FRAME:
            self.log = wrap_lines(self.battle.final_data['amrita_release'][1:] or
                                  self.battle.final_data['amrita_release'], 37)[-3:]

    def cure_target_hint(self, skill, targets):
        """Advisory only: healthy allies remain legal queued cure targets."""
        if skill and skill.effect == 'cure' and not any(
                target.alive and set(active_statuses(target)) & set(skill.cure_statuses)
                for target in targets):
            return "治療対象なし"
        return ""

    def skill_details(self, actor, skill, y=76):
        pyxel.line(4, y - 3, 155, y - 3, 1)
        text(5, y, f"{RARITIES[skill.rarity]} / {TARGETS[skill.target]} 最大{actor.max_uses(skill)}回", 2, 37)
        text(5, y + 8, skill.formula(), 3, 37)
        detail = f"威力 {skill.power(actor)} 待ち {skill.cooldown}T"
        if actor.power_multiplier(skill) > 1:
            detail += " / MASTER x1.2"
        if skill.effect == "berserk":
            detail = "STR x1.5 / 被害 x1.25 / 3T"
        elif skill.effect in EFFECTS:
            detail = EFFECTS[skill.effect] + " / 重複せず更新"
        elif skill.effect == "return":
            detail = f"未確定{CURRENCY_NAME}を持ち帰る"
        elif skill.effect == "revive":
            detail = "戦闘不能の味方1人 / 残数制"
        if skill.target == 'all_allies':
            hint = self.cure_target_hint(skill, self.session.party)
            if hint:
                detail = hint + (" / 予約可" if self.state == 'skill' else "")
        text(5, y + 16, detail, 2, 37)
        if not hasattr(self, 'description_scroll'):
            self.description_scroll = DescriptionScroll()
        self.description_scroll.draw(5, y + 24, skill.description, 2, 37,
            context=(self.state, self.overlay, self.info_character, self.info_tab,
                     actor.party_id, skill.id))

    def draw_skills(self):
        if not self.actor.skills:
            self.title(f"{self.actor.name} / 技なし")
            self.footer("B:戻る")
            return
        self.skill_cursor = min(max(0, self.skill_cursor), len(self.actor.skills) - 1)
        self.title(f"{self.actor.name} / 技 {self.skill_cursor + 1}/{len(self.actor.skills)}")
        start = max(0, self.skill_cursor - 5)
        for row, skill_id in enumerate(self.actor.skills[start:start + 6]):
            skill = self.session.skills[skill_id]
            selected = start + row == self.skill_cursor
            y = 16 + row * 9
            if selected:
                pyxel.rect(3, y - 1, 154, 8, 1)
            text(5, y, (">" if selected else " ") + skill.name, 3, 23)
            wait = self.actor.cooldowns.get(skill_id, 0)
            text(101, y, f"{self.actor.skill_uses.get(skill_id, 0)}/{self.actor.max_uses(skill)}" + ("待" if wait else ""), 2, 14)
        self.skill_details(self.actor, self.session.skills[self.actor.skills[self.skill_cursor]])
        self.footer("D-PAD:選択 A:使用 B:戻る")

    def draw_battle_items(self):
        self.title(f"{self.actor.name} / ITEM")
        options = self.battle_items()
        if not options:
            text(8, 30, "使える道具がありません", 3, 35)
        for i, item in enumerate(options):
            if item == AMRITA_ITEM_ID:
                label = 'アムリタ / KEY ITEM'
            else:
                remaining = self.session.inventory.counts[item] - sum(a.kind == "ITEM" and a.item_id == item for a in self.actions)
                label = f'{self.session.inventory.label(item)} x{remaining}'
            text(8, 24 + i * 14, (">" if i == self.item_cursor else " ") +
                 label, 3 if i == self.item_cursor else 2, 36)
        if AMRITA_ITEM_ID in options and self.item_cursor == options.index(AMRITA_ITEM_ID):
            text(8, 78, '特殊な障壁を解除 / 1ターン', 2, 36)
            text(8, 90, '道具数と技Usesは消費しない', 2, 36)
        elif options:
            text(8, 78, self.session.inventory.description(options[self.item_cursor]), 2, 36)
        self.footer("上下:選択 A:使用 B:戻る")

    def draw_result(self):
        outcome = self.battle.outcome
        spark = any("閃き!" in line for line in self.session.results)
        self.title(f"{OUTCOMES[outcome]} / " + ("新たな技の閃き!" if spark else "成長結果"))
        text(5, 15, f"{self.session.completed}戦 {self.session.wins}勝 {self.session.losses}敗 {self.session.draws}分", 2, 37)
        pages_data = getattr(self, 'growth_result_pages', ())
        page = pages_data[self.result_page] if self.result_page < len(pages_data) else None
        if page and page['kind'] == 'growth':
            actor = self.session.party[page['actor']]
            pyxel.blt(20, 27, 0, *actor.sprite, 16, 16, 0)
            text(43, 30, actor.name, 3, 27)
            for i, line in enumerate(page['lines'][1:]):
                text(46, 49 + i * 11, line, 3, 25)
        else:
            for i, line in enumerate(self.result_lines[self.result_page * 9:self.result_page * 9 + 9]):
                text(7, 27 + i * 8, line, 3 if "閃き" in line or "伝説" in line else 2, 36)
        pages = max(1, (len(self.result_lines) + 8) // 9)
        text(5, 102, f"{self.result_page + 1}/{pages}ページ", 3, 37)
        next_label = "入替へ" if self.session.pending_replacements else self.next_result_label()
        if self.result_page == pages - 1 and self.waiting_for_fanfare():
            self.footer("")
            return
        self.footer(f"A:{next_label} D-PAD:ページ" if self.result_page == pages - 1 else "A:続きを読む D-PAD:ページ")

    def info_scroll_limit(self):
        actor = self.session.party[self.info_character]
        if self.info_tab == 1:
            return max(0, len(actor.skills) - 1)
        if self.info_tab == 2:
            return max(0, len(wrap_lines(list(reversed(actor.history)), 36)) - 8)
        return 0

    def draw_info(self):
        actor = self.session.party[self.info_character]
        tab = ("能力", "習得技", "履歴")[self.info_tab]
        self.title(f"< {actor.name}/{TYPES.get(actor.growth_type, actor.growth_type)} > {tab}")
        text(5, 15, f"BATTLES {self.session.total_battles}  {self.session.wins}勝 {self.session.losses}敗 {self.session.draws}分", 2, 37)
        if self.info_tab == 0:
            pyxel.blt(10, 30, 0, *actor.sprite, 16, 16, 0)
            draw_status_icons(pyxel, actor, 10, 50, limit=2)
            text(34, 29, f"HP {actor.hp}/{actor.max_hp}", 3, 30)
            text(34, 39, f"STR {actor.strength}  AGI {actor.agility}", 3, 30)
            slots = self.session.settings["skill_slots"]
            text(34, 49, f"INT {actor.intellect} 技 {len(actor.skills)}/{slots}", 3, 30)
            text(5, 64, "基本成長率 / 使用補正", 2)
            rates = self.session.settings["growth_rates"][actor.growth_type]
            for i, stat in enumerate(("HP", "STR", "AGI", "INT")):
                extra = growth_bonus(actor, stat, self.session.settings)
                text(8, 73 + i * 8, f"{stat:3} {rates[stat]:.0%}  +{extra:.0%}", 3, 36)
        elif self.info_tab == 1:
            if actor.skills:
                start = max(0, self.scroll - 5)
                for i, skill_id in enumerate(actor.skills[start:start + 6]):
                    skill = self.session.skills[skill_id]
                    selected = start + i == self.scroll
                    text(5, 24 + i * 8, (">" if selected else " ") + f"{start+i+1}." + skill.name, 3 if selected else 2, 23)
                    text(101, 24 + i * 8, f"{actor.skill_uses.get(skill_id, 0)}/{actor.max_uses(skill)}", 2, 14)
                self.skill_details(actor, self.session.skills[actor.skills[self.scroll]])
            else:
                text(8, 35, "技はまだ覚えていません", 3)
                text(8, 47, "勝利すると閃くかも!", 2)
                text(8, 59, "初戦から伝説の技も対象", 2)
        else:
            lines = wrap_lines(list(reversed(actor.history)), 36) or ["まだ履歴がありません"]
            for i, line in enumerate(lines[self.scroll:self.scroll + 8]):
                text(7, 27 + i * 9, line, 3 if "閃き" in line else 2, 36)
            text(5, 102, "上下:スクロール 新しい順", 2)
        self.footer(("上下:人 左右:頁 B:閉じる", "左右:頁 上下:技 A:使用 B:戻る",
                     "左右:頁 上下:履歴 B:戻る")[self.info_tab])

    def draw_help(self):
        self.title("ヘルプ / 操作")
        lines = ["D-PAD  移動・選択", "A  決定・調べる・会話送り", "B  キャンセル・戻る", "探索中のB  メニュー", "PC: A=Zキー B=Xキー",
                 "戦闘 SKILL/ITEM/GUARD/RUN", "GUARD:今ターンの被害半減", "技は使い切ると消滅"]
        for i, line in enumerate(lines):
            text(5, 18 + i * 10, line, 3 if i < 5 else 2, 37)
        self.footer("B:閉じる")

    def update_replacement(self, confirm, cancel):
        index = self.session.pending_replacements[0]
        actor = self.session.party[index]
        if self.replacement_confirm:
            if cancel:
                self.replacement_confirm = False
            elif confirm:
                slot = self.replacement_cursor if self.replacement_cursor < len(actor.skills) else None
                try:
                    self.session.resolve_replacement(index, slot)
                except ValueError as error:
                    self.tell(str(error))
                    return
                self.notice_timer = 0
                self.replacement_confirm = False
                self.replacement_cursor = 0
                if not self.session.pending_replacements:
                    if self.debug_return_state is not None:
                        self.state, self.debug_return_state = self.debug_return_state, None
                        self.overlay = self.debug_return_overlay if self.session.debug else None
                        self.debug_return_overlay = "debug_skills"
                        return
                    self.finish_results()
            return
        self.replacement_cursor = (self.replacement_cursor + self.direction()) % (len(actor.skills) + 1)
        if cancel:
            self.replacement_cursor = len(actor.skills)
        elif confirm:
            self.replacement_confirm = True

    def update_rescue_notice(self):
        """Use the ordinary message panel for previously silent rescue paths.

        Round-end and field-skill rescues already use their existing log queues.
        Only battle-entry/replacement notices pass through this transient panel.
        """
        if self.overlay == 'rescue':
            if self.rescue_input_blocked:
                if not (self.confirm_held() or pyxel.btn(pyxel.KEY_X)
                        or pyxel.btn(pyxel.GAMEPAD1_BUTTON_B)):
                    self.rescue_input_blocked = False
                return True
            if self.confirm() or self.cancel():
                self.rescue_offset += 3
                if self.rescue_offset >= len(self.rescue_lines):
                    self.overlay = None
                else:
                    self.rescue_input_blocked = True
            return True
        if (self.session.rescue_notices and self.overlay is None
                and self.state not in ('title', 'title_no_save', 'title_fade', 'intro',
                    'hub_preview', 'hub_intro', 'battle_transition', 'amrita_effect')):
            self.rescue_lines = wrap_lines(self.session.rescue_notices, 36)
            self.session.rescue_notices.clear()
            self.rescue_offset, self.rescue_input_blocked = 0, True
            self.overlay = 'rescue'
            return True
        return False

    def draw_rescue_notice(self):
        self.panel(0, 79, 160, 32)
        for row, line in enumerate(self.rescue_lines[self.rescue_offset:self.rescue_offset + 3]):
            text(5, 83 + row * 8, line, 3, 36)
        self.footer('A/B:次へ')

    def draw_replacement(self):
        actor = self.session.party[self.session.pending_replacements[0]]
        new = self.session.skills[actor.pending_skill]
        relearn = self.session.pending_relearn is not None
        uses = actor.relearn_uses(new) if relearn else actor.next_max_uses(new)
        bonus = " / POWER x1.2" if actor.next_power_multiplier(new) > 1 else ""
        self.title(f"{actor.name} / 技の入れ替え{bonus}")
        text(4, 14, f"新: {self.mastered_label(new)}", 3, 38)
        preview_power = new.power(actor, next_copy=True)
        text(4, 23, f"{new.relearn_cost} {CURRENCY_NAME} / 威力{preview_power} {uses}/{actor.next_max_uses(new)}回" if relearn else f"{RARITIES[new.rarity]} 威力{preview_power} {uses}/{actor.next_max_uses(new)}回", 2, 38)
        if self.replacement_confirm:
            if self.replacement_cursor < len(actor.skills):
                old = self.session.skills[actor.skills[self.replacement_cursor]]
                text(4, 42, f"忘れる: {self.mastered_label(old)}", 2, 38)
                text(4, 66, f"残数 {actor.skill_uses[old.id]}/{actor.max_uses(old)} 完全に失う", 2, 38)
                text(4, 56, f"覚える: {self.mastered_label(new)}", 3, 38)
                text(4, 77, "この技に入れ替えますか?", 3, 38)
                if new.effect not in ("damage", "drain") and not any(self.session.skills[s].effect in ("damage", "drain") for s in actor.skills if s != old.id):
                    text(4, 91, "攻撃技を1つ残してください" if relearn else "攻撃技がなくなります", 3, 38)
            else:
                text(4, 48, "新しい技を覚えずに", 2, 38)
                text(4, 62, "見送りますか?", 3, 38)
            self.footer("A:確定 B:選び直す")
            return
        start = max(0, self.replacement_cursor - 4)
        choices = [self.mastered_label(self.session.skills[s]) for s in actor.skills] + ["新しい技を見送る"]
        for row, label in enumerate(choices[start:start + 5]):
            selected = start + row == self.replacement_cursor
            y = 35 + row * 10
            if selected:
                pyxel.rect(2, y - 1, 156, 9, 1)
            is_old = start + row < len(actor.skills)
            text(4, y, (">" if selected else " ") + f"{start + row + 1}." + label, 3 if selected else 2, 23 if is_old else 38)
            if is_old:
                sid = actor.skills[start + row]
                text(100, y, f"{actor.skill_uses.get(sid, 0)}/{actor.max_uses(self.session.skills[sid])}", 2, 14)
        if self.replacement_cursor < len(actor.skills):
            old = self.session.skills[actor.skills[self.replacement_cursor]]
            text(4, 88, f"旧: {RARITIES[old.rarity]} 威力{old.power(actor)} 待ち{old.cooldown}T", 2, 38)
            text(4, 99, old.formula(), 2, 38)
        else:
            text(4, 92, "覚えている技をそのまま残す", 2, 38)
        self.footer("上下:忘れる技 A:選択 B:見送る")

    def mastered_label(self, skill):
        return skill.name + ('★' if skill.id in self.session.mastered_skills else '')

    def update_debug_skills(self, confirm):
        self.info_character = (self.info_character + self.direction(horizontal=True)) % 4
        self.debug_cursor = (self.debug_cursor + self.direction()) % 6
        if confirm:
            operation = ("one", "restore", "random", "rare", "legend", "fill")[self.debug_cursor]
            try:
                lines = self.session.debug_skills(operation, self.info_character)
            except ValueError as error:
                self.tell(str(error))
                return
            self.tell(lines[-1])
            if self.session.pending_replacements:
                self.debug_return_state = self.state
                self.debug_return_overlay = "debug_skills"
                self.state, self.overlay = "replace", None
                self.replacement_cursor, self.replacement_confirm = 0, False
                self.notice_timer = 0

    def draw_debug_skills(self):
        actor = self.session.party[self.info_character]
        self.title(f"DEBUG 技 / <{actor.name}>")
        labels = ("全員:残り1回にする", "全員:残数を最大に戻す", "選択者:ランダムに閃く", "選択者:希少以上を閃く", "選択者:伝説を閃く", "選択者:技枠を満杯にする")
        for i, label in enumerate(labels):
            text(5, 18 + i * 12, (">" if i == self.debug_cursor else " ") + label, 3 if i == self.debug_cursor else 2, 37)
        text(5, 94, "満杯→伝説で入れ替えを試す", 2, 37)
        self.footer("左右:人 上下:項目 Z:実行 X:戻る")
