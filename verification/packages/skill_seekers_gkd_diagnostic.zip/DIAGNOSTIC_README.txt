GKD Pixel 2 戦闘開始診断版

ZIPを展開し、Skill_Seekersフォルダを既存フォルダへ「上書き/結合」します。
既存のsaveフォルダは削除しないでください。ZIPにはセーブを含みません。
Skill_Seekers_Diagnostic.shを既存Skill_Seekers.shと同じ階層へコピーします。
診断時はSkill_Seekers_Diagnostic.shを起動してください。
通常ランチャーの名前/内容はこのZIPでは上書きしません。
診断ランチャーも既存のsave/save.jsonを使い、既存SAVE/LOADの仕様のままです。

Skill_Seekers/diagnostic_config.jsonをメモ帳で編集できます。
デフォルト: battle_start_audio=true, skip_transition=false, watchdog_seconds=20
まずデフォルトで試してください。
比較B: battle_start_audio=false（戦闘突入SE/BGM要求だけ無効、戦闘ロジックは同じ）
比較C: skip_transition=true（既存の演出なし開始経路を診断時だけ使用）
2つ同時に変えず、一度に1項目を変更してください。設定は次回起動から有効です。

フリーズ後はPC/ファイルマネージャーで以下を回収してください。
Skill_Seekers/diagnostics/battle_start.jsonl
Skill_Seekers/diagnostics/battle_start.jsonl.1（あれば）
Skill_Seekers/diagnostics/python_stacks.log
Skill_Seekers/diagnostics/python_stacks.log.1（あれば）
ランチャーと同じフォルダ/skill_seekers_diagnostic_launch.log
save/save.jsonの提出は不要です。

ログはCheckpointごとにflush、戦闘開始音声要求直前/COMMAND_READY/例外ではfsync。
JSONLは最大256KiB×2。スタックは20秒更新が途絶えたとき1回出力します。
faulthandler未対応時はWATCHDOG_UNAVAILABLEを記録し、Checkpointは継続します。
input lock中にボタンが押され続けている場合はINPUT_HELDでキー番号を記録します。
ログを編集/消去する場合はゲームを終了してから行ってください。

この診断版にもネイティブplaym停止の最小回避を含みます。
Skill、Enemy、マップ、SAVE形式、遷移タイマーは通常修正版と同じです。
診断が不要になったら通常Skill_Seekers.shから起動できます。
